/******************************************************************************
* File Name:   cstringgrid.h
* Author:      D. Van Leer
* Date:        05/23/03
* Copyright:   2003 D. Van Leer
* Description: stringgrid class header
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
******************************************************************************/
#ifndef CStringGridH
#define CStringGridH

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxcview.h>

#include "../resource.h"

#undef  WINVER
#define WINVER 0x0500

#include <windows.h>
#include <string>
#include <vector>
using namespace std;

#define minmax(a,x,b) (min(max(x, a), b))
#define MAX_ROWS        2048
#define MAX_COLS          80
#define MAX_COLUMN_CHARS  80
#define NO_COLOR		  (COLORREF)(-1)

// notification messages sent to parent
#define SGN_CELLCHANGED (WM_USER + 1961)
#define SGN_RIGHTCLICK  (WM_USER + 1962)

// option flags
const DWORD SGO_NONE          = 0x00000000; // no options
const DWORD SGO_VISIBLE       = 0x00000001; // grid visible
const DWORD SGO_CELLSEL       = 0x00000002; // select single cell
const DWORD SGO_ROWSEL        = 0x00000004; // select whole row
const DWORD SGO_COLSEL        = 0x00000008; // select whole column
const DWORD SGO_EDITABLE      = 0x00000010; // allow editing cells
const DWORD SGO_SCROLLDOT     = 0x00000020; // grid scrolled indicators
const DWORD SGO_AUTOSIZE      = 0x00000040; // autosize columns
const DWORD SGO_FIXEDCOL      = 0x00000080; // show fixed column
const DWORD SGO_FIXEDROW      = 0x00000100; // show fixed row
const DWORD SGO_USERSIZE      = 0x00000200; // user sizable columns
const DWORD SGO_EXTENDLINES   = 0x00000400; // extend grid lines if last
                                            //    column/row offscreen
const DWORD SGO_EXTENDCELLS   = 0x00000800; // extend last col & row if cells
                                            //    don't fill client area
const DWORD SGO_NUMBERROWS    = 0x00001000; // row numbers in fixed column */
const DWORD SGO_SHOWFOCUS     = 0x00002000; // show not focused by graying text
const DWORD SGO_TITLE         = 0x00004000; // show title at top of grid
const DWORD SGO_XPSTYLE       = 0x00008000; // new style fixed cells and
                                            //    selected cell
const DWORD SGO_XPHORZ        = 0x00010000; // fixed col horizontal gradient
const DWORD SGO_ROWBARS       = 0x00020000; // color alternate rows

// attribute flags (for columns)
const WORD SGA_ALIGNCENTER    = 0x0001;
const WORD SGA_ALIGNLEFT      = 0x0002;
const WORD SGA_ALIGNRIGHT     = 0x0004;
const WORD SGA_NOEDIT         = 0x0008;
//
const WORD SGA_PLAIN          = 0x0100;
//const WORD SGA_BOLD           = 0x0200;
//const WORD SGA_ITALIC         = 0x0400;
//
//const WORD SGA_TEXT           = 0x1000;
//const WORD SGA_NUMBER         = 0x2000;
//const WORD SGA_MONEY          = 0x4000;
//const WORD SGA_DATE           = 0x8000;

// color indices
enum SGC_ENUM 
{
  SGC_TEXT_0 = 0, SGC_TEXT_1,       // 16 cell text colors
  SGC_TEXT_2,     SGC_TEXT_3,
  SGC_TEXT_4,     SGC_TEXT_5,
  SGC_TEXT_6,     SGC_TEXT_7,
  SGC_TEXT_8,     SGC_TEXT_9,
  SGC_TEXT_A,     SGC_TEXT_B,
  SGC_TEXT_C,     SGC_TEXT_D,
  SGC_TEXT_E,     SGC_TEXT_F,

  SGC_COLUMN_1,   SGC_COLUMN_2,     // 4 column colors
  SGC_COLUMN_3,   SGC_COLUMN_4,

  SGC_GRIDBKGND,                    // grid background
  SGC_CELLBKGND,                    // cell background
  SGC_EDITBKGND,                    // edit cell background
  SGC_FXDCELL,                      // fixed cell backgrouond
  SGC_SELCELL,                      // selected cell background

  SGC_FXDCOLTEXT,                   // fixed column text
  SGC_FXDROWTEXT,                   // fixed row text
  SGC_TITLETEXT,                    // title cell text
  SGC_EDITTEXT,                     // edit cell text
  SGC_SELTEXT,                      // selected cell text
  SGC_GRAYTEXT,                     // grayed text when unfocused

  SGC_SELBORDER,                    // selected cell border
  SGC_EDITBORDER,                   // edit cell border
  SGC_GRIDLINE,                     // grid lines
  SGC_SCROLLDOT,                    // scroll dot outline
  SGC_ODDROWBARS,                   // odd row color for rowstripe option
  SGC_GRADTOP,
  SGC_GRADBOTTOM,
  NUM_COLORS                        // last value = number of colors
};
const DWORD SGC_ERROR = 0xFF000000; // value to return if error

// font indices
enum SGF_ENUM
{
  SGF_FIXEDCELLS,                   // fixed column/row font
  SGF_CELLS,                        // normal cell font
  SGF_TITLE,                        // title font
  SGF_EDIT                          // edit mode font, must be fixed width font
};

// class declarations
// cell class
class CellType
{
  public:
    CellType() :
      m_string  (""),
     m_color   (NO_COLOR),
      m_style   (SGA_PLAIN)
      {};

    string      m_string;
    COLORREF    m_color;
    WORD        m_style;
};

class CloakCellType : public CellType
{
public:
	CloakCellType() : CellType(),colspan(1),rowspan(1),in_span(false),corner(true) {};
	int colspan; 
	int rowspan; 
	bool in_span;
	bool corner;
};

class CloakRowType 
{
public:
	CloakRowType(int h = -1) : height_per100(h) , m_color(NO_COLOR){};
	vector <CloakCellType> m_cloakcells;
	
//	friend class RowType;
//private
	int height_per100;
	int pixel_height;
	COLORREF    m_color;
    WORD        m_style;
};


class CloakColType
{
public:
//	friend class RowType;
	CloakColType(int w = -1) : width_per100(w) {};
//private:
	int width_per100;
	int percent_width;

};


#define DEFAULT_ROW_COLOR RGB(255,255,255)
#define DEFAULT_COL_COLOR DEFAULT_ROW_COLOR


class RowType
{


  public:

//	  friend class CloakRowType;
//	  friend class CloakColType;

	  RowType() :
	  hidden		(true), // change this, changed was false
	  cloakH(48),
      m_color   (DEFAULT_ROW_COLOR),
      m_style   (SGA_PLAIN),
	  cloakcols(0),
	  cloakrows(0),
	  visible(true),
	  userdata(0),
	  userptr(NULL),
	  selected(false)
      {};

	  void toogle_select() { selected = !selected; };
	  void toogle() { hidden = !hidden; };
	  void show() { hidden = false; };
	  void hide() { hidden = true; };
	  int CloakHeight() { return (hidden ? 0 : cloakH); };
	  bool SetCloakH(int H) 
	  { 
		  if(H > 0) 
		  {
			  cloakH = H; 
			  MergeRows();
			  return TRUE;
		  }

		  return FALSE;
	  };
	  bool SetCloakRowHeight(int row, int percent);
	  bool SetCloakColWidth(int col,int percent);
	  bool SetCloakSize(int rows,int cols);
	  bool SetCloakCellColor(int col,int row,COLORREF color);
	  bool SetCloakCell(int col,int row,string &celltext);
	  bool SetCloakCellSpan(int col,int row,int colspan,int rowspan);

	  
	vector<CloakColType> m_CloakCols;

	vector<CloakRowType> m_CloakRows;

	bool selected;
	bool hidden; 
	vector<CellType>    m_cells;
    COLORREF    m_color;
    WORD        m_style;

  //private:
	int cloakcols;
	int cloakrows;
	int cloakH;
	bool visible;
	
	DWORD userdata;
	void * userptr;

void MergeRows(void)
{

		int i,p100rcount = 0,rper100height = 0,t,correct = 0,h;

		for(i=0;i<cloakrows;i++)
		{
			t = m_CloakRows[i].height_per100;
			if(t<0) p100rcount++;
			else rper100height += t;
		}

		if(rper100height > 100)
		{
			for(i=0;i<cloakrows;i++)
			{
				t = m_CloakRows[i].height_per100;
				if(t < 0) m_CloakRows[i].pixel_height = 0;
				else 
				{
					h = (t*cloakH)/rper100height;
					m_CloakRows[i].pixel_height = h;
					correct += h;
				}
			}
		} else
		{
			for(i=0;i<cloakrows;i++)
			{
				t = m_CloakRows[i].height_per100;
				if(t < 0) 
				{
					h = ((100-rper100height)*cloakH)/(p100rcount*100);
					m_CloakRows[i].pixel_height = h;

				}
				else 
				{
					h = (t*cloakH)/100;
					m_CloakRows[i].pixel_height = h;
				}
				correct += h;
			}
		


		}

		if(cloakH > correct)
		{

			i = cloakrows-1;
			for(;i >= 0;i--)
				if(m_CloakRows[i].pixel_height > 0) 
				{
					m_CloakRows[i].pixel_height  += (cloakH-correct);
					break;
				}

		}




};
void MergeCols(void)
{


		int i,p100ccount = 0,cper100width = 0,t,correct = 0,w;

		for(i=0;i<cloakcols;i++)
		{
			t = m_CloakCols[i].width_per100;
			if(t<0) p100ccount++;
			else cper100width += t;
		}


		if(cper100width > 100)
		{
			for(i=0;i<cloakcols;i++)
			{
				t = m_CloakCols[i].width_per100;
				if(t < 0) w = 0;
				else w = (t*100)/cper100width;

				m_CloakCols[i].percent_width = w;
				correct += w;
			}
		} 
		else
		{
			for(i=0;i<cloakcols;i++)
			{
				t = m_CloakCols[i].width_per100;
				if(t < 0) w = (100-cper100width)/(p100ccount);
				else w = t;

				m_CloakCols[i].percent_width = w;
				correct += w;
			}
		


		}


	if(100 > correct)
	{

			i = cloakcols-1;
			for(;i >= 0;i--)
				if(m_CloakCols[i].percent_width > 0) 
				{
					m_CloakCols[i].percent_width  += (100-correct);
					break;
				}

	}








};






};


// column class
class ColumnType
{
  public:
    
    ColumnType(int width = 100) :
    //  m_color  (SGC_CELLBKGND),
    //  m_style  (SGA_ALIGNCENTER),
	  m_width  (width) {};

    int         m_width;
   // SGC_ENUM    m_color;
   // WORD        m_style;
};



// grid class
class CStringGrid : public CScrollView
{
    

protected:

	 // constructor & destructor
    CStringGrid(int cols = 5, int rows = 5); // protected constructor used by dynamic creation
  
           
	DECLARE_DYNCREATE(CStringGrid)

	virtual void OnInitialUpdate(); // called first time after construct
	 virtual ~CStringGrid();

	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
    	
	// static message handler to put in WNDCLASSEX structure
    static    LRESULT CALLBACK stWinMsgHandler(HWND hwnd, UINT uMsg, 
                                            WPARAM wParam, LPARAM lParam);

    // functions
    ATOM      Register(HINSTANCE hinst);
    BOOL      Create(HWND hParent, UINT uID, RECT* rect,
                     DWORD dwStyle = 0, DWORD dwExStyle = 0);
public:
    LPCTSTR   Cell(int col, int row);
    string    CellString(int col, int row);

    HWND      Handle(){return m_gridhWnd;};
    COLORREF  SetColor(DWORD index, COLORREF color);
    COLORREF  GetColor(DWORD index);
    COLORREF  GetCellColor(int col, int row);
    WORD      GetCellStyle(int col, int row);
    void      SetCellStyle(int col, int row, WORD style);
    void      SetCellColor(int col, int row, COLORREF color);
    void      SetColStyle(int col, WORD style);
    void      SetColColor(int col, SGC_ENUM color);
    WORD      GetColStyle(int col); 
    int       GetColColor(int col);
    void      SetTitleString(string s);
    string    GetTitleString();
//	bool	  SetSize(int rows,int cols); better use ResizeGrid
    
    int       Column()    {return m_col;};      // return selected column
    int       Row()       {return m_row;};      // return selected row
    int       ColCount()  {return m_colCount;}; // return number of columns
    int       RowCount()  {return m_rowCount;}; // return number of rows
    int       TopRow()    {return m_topRow;};   // return top visible row
    int       LeftColumn(){return m_leftCol;};  // return left visible column
    int       RightColumn();                    // return right visible column
    int       BottomRow();                      // return bottom visible row
  
    void      SetColumn(int col);               // set selected column
    void      SetLeftCol(int col);              // set left displayed column
    void      SetRow(int row);                  // set selected row
    void      SetTopRow(int row);               // set top displayed row

    void      NumberRows(int start, int step);
    void      SetNumRowParams(int start, int step);

    void      InsertCol(int col, int width);    // insert column
    int      InsertRow(int row  = -1);               // insert row , -1 at begin
    bool      DeleteCol(int col);               // delete column
    bool      DeleteRow(int row);               // delete row
    bool      AutoSizeCol(int col);             // fit column to text
    bool      ResizeGrid(int cols, int rows);
    void      ClearGrid();
    
    void      AddOptions(DWORD options);        // add options
    void      DelOptions(DWORD options);        // delete options
    bool      CheckOptions(DWORD options);      // check if options set
    DWORD     GetOptions() {return m_dwOptions;};
    void      SetOptions(DWORD options);        // set options

    void      DrawGrid();                       // draw the grid
    void      SetColCharWidths(int widths[]);
    bool      SetColWidth(int col, int width);
    void      SetRowHeight(int height);
    void      SetTitleHeight(int height);
    void      SetVisible(bool v);

    bool      GetCellRect(int c, int r, RECT& rc);
    bool      HitTestCell(int x, int y, int& c, int& r);
    bool      LoadFromFile();
    bool      SaveToFile();
    bool      SetCell(int col, int row, string s);
    void      SetFont(SGF_ENUM font, LOGFONT lf);
    bool      Visible();
    inline int       VisibleRows();
    int       AvgColWidth();
	int		  GetColWidth(int col);
    int       HeadHeight();
    int       TitleHeight();
	void	  FreezHighlight(void);
	void	  UnFreezHighlight(void);
	void*	  GetHighlightedRowPtr(void);
	bool      SetRowCloakSize(int row,int cloakrows,int cloakcols);
	void      SetRowVisible(int iRow,bool bVis);
	void      ToggleVisible(int iRow);
	inline int       GetHighlightedRow(void)
	{
		return m_row_hlight;
	};

	bool GetRowVisible(int row)
	{
		VERIFY(row > 0 && row < m_rowCount);
		return m_rows[row].visible;
	};

	bool SetRowColor(int row,COLORREF color);

	RowType *GetRowPtr(int row);





  //ivate:

    void      InitEdit(int col, int row);
    void      EditKeydown(WPARAM wParam);
    void      EditChar(WPARAM wParam);
    void      DrawEdit();
    bool      CursorLeft();
    bool      CursorRight();
    void      BtnCell(RECT rc);
    bool      CellExists(int col, int row);
    void      SetScrollbars();

	void	ReDraw(void)
	{
		DrawGrid();
		SetScrollbars();
	};

    static bool     sg_Registered;          // class registered flag


    HINSTANCE       m_hInst;                // instance handle
    HWND            m_gridhWnd;                 // window handle
    HDC             m_memdc;                // virtual canvas dc
    BOOL            m_bWindowClosed;        // window close flag ?
    RECT            m_clRect;               // client rectangle
    UINT            m_uID;                  // unique ID
    HBITMAP         m_hBitmap;              // virtual canvas bitmap
    HGDIOBJ         m_hOldBitmap;           // handle of default dc bitmap

    int             m_top;                  // top of grid
    int             m_left;                 // left of grid
    int             m_width;                // window width
    int             m_height;               // window height
	int			    m_ScreenRows ;

	int				m_row_hlight;			// highlighted row

    int             m_col;                  // selected column
    int             m_row;                  // selected row
    int             m_colCount;             // number of columns
    int             m_rowCount;             // number of rows
    int             m_rowHeight;            // height of a row
    int             m_titleHeight;          // height of title
    int             m_leftCol;              // left visible col
    int             m_rightCol;             // right visible col
    int             m_topRow;               // top visible row
    int             m_bottomRow;            // bottom visible row
    
    int             m_numRowStart;
    int             m_numRowStep;
    
    int             m_xCaret;               // edit field caret x coord
    int             m_yCaret;               // edit field caret y coord
    int             m_editCharWidth;        // width of edit field characters
    int             m_editPos;              // current edit position
    int             m_editBegin;            // start coord of edit field
    int             m_editEnd;              // end coord of edit field
    int             m_editOffset;           // offset to first visible edit char
    int             m_editCursor;           // edit cursor position
    int             m_editSize;             // visible chars in edit field
    
    bool            m_bFocused;             // grid focused flag
    bool            m_bGrayed;              // grayed if not focused flag
    bool            m_bSizing;              // column sizing flag
    bool            m_bSizeGrip;
    int             m_sizingCol;
    int             m_sizingLeft;
	int				m_VisRows;

    DWORD           m_dwOptions;            // option flags
    DWORD           m_dwExStyle;            // extended window style
    DWORD           m_dwStyle;              // window style
    LOGFONT         m_fxFont;               // fixed col/row font
    LOGFONT         m_cellFont;             // grid cell font
    LOGFONT         m_editFont;             // edit mode font
    LOGFONT         m_titleFont;            // title font
    COLORREF        m_colors[NUM_COLORS];   // array of colors
        
    SCROLLINFO      m_si;                   // scrollbar info
  
    string          m_editString;           // string being edited
    string          m_escString;            // copy of unedited string
    string          m_titleString;
   /* HMENU           m_hMenuTop;
    HMENU           m_hMenuPopup;
    HMENU           m_hMenuTip;
    HMENU           m_hMenuTip2;*/

	vector<RowType>		m_rows;
    vector<CellType>    m_cells;
    vector<ColumnType>  m_columns;              // column info

	CImageList m_imgList;
	CBitmap     m_SelectImage;
	BITMAP      m_SelectBitmap;
	bool m_bFreezHighlight;

    // the message handler for this window
    LRESULT CALLBACK WinMsgHandler(HWND hwnd, UINT uMsg, 
                                   WPARAM wParam, LPARAM lParam);

  	// returns a pointer to the window (stored as the WindowLong)
    inline static CStringGrid *GetObjectFromWindow(HWND hWnd)
    {
      return (CStringGrid *)GetWindowLong(hWnd, GWL_USERDATA);
    }

protected:
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	//{{AFX_MSG(CDummyList)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnPaint();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSetFocus(CWnd* pOldWnd); 
	//afx_msg void OnContextMenu(CWnd *pWnd,CPoint pos);

	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

#endif



