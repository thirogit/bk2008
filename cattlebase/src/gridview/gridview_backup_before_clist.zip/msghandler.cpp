/******************************************************************************
* File Name:   msghandler.cpp
* Author:      D. Van Leer
* Date:        11/01/03
* Copyright:   2003 D. Van Leer
* Description: stringgrid class message handler function
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
******************************************************************************/
#include "stdafx.h"
#include "cstringgrid.h"
#include <cctype>


LRESULT CALLBACK 
CStringGrid::WinMsgHandler(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  switch (uMsg)
	{
    case WM_CREATE:
    {
      TEXTMETRIC  tm;
      HBRUSH      hbBkgd  = CreateSolidBrush(m_colors[SGC_GRIDBKGND]);
      HFONT       hfEdit  = CreateFontIndirect(&m_editFont);
      int         maxX    = GetSystemMetrics(SM_CXSCREEN);
      int         maxY    = GetSystemMetrics(SM_CYSCREEN);
      HDC         hdc     = ::GetDC(hwnd);
      
      m_memdc   = CreateCompatibleDC(hdc);
      m_hBitmap = CreateCompatibleBitmap(hdc, maxX, maxY);
      ::ReleaseDC(hwnd, hdc);

      m_hOldBitmap = SelectObject(m_memdc, m_hBitmap);

      int         iSaveDC = SaveDC(m_memdc);

      // get edit character width
      SelectObject(m_memdc, hfEdit);
      GetTextMetrics(m_memdc, &tm);
      m_editCharWidth = (int)tm.tmMaxCharWidth;

      // fill background
      SelectObject(m_memdc, hbBkgd);
      PatBlt(m_memdc, 0, 0, maxX, maxY, PATCOPY);

      RestoreDC(m_memdc, iSaveDC);
      DeleteObject(hbBkgd);
      DeleteObject(hfEdit);


      // create popup menu
/*      m_hMenuTop    = CreateMenu();
      m_hMenuPopup  = CreateMenu();
      AppendMenu(m_hMenuPopup, MF_STRING, 900, "Cu&t");
      AppendMenu(m_hMenuPopup, MF_STRING, 901, "&Cop&y");
      AppendMenu(m_hMenuPopup, MF_STRING, 902, "&Paste");
      AppendMenu(m_hMenuTop, MF_POPUP, (UINT)m_hMenuPopup, "test");*/
      

      break;   
    } // WM_CREATE
    
    case WM_GETDLGCODE:
      return DLGC_WANTALLKEYS;
    break;
    
    case WM_MOUSEMOVE:
    {

     int xPos = LOWORD(lParam);  // horizontal position of cursor 
     int yPos = HIWORD(lParam);  // vertical position of cursor 
	
		
	  int   cellcol, cellrow;
      bool  b;
      b = HitTestCell(xPos,yPos,cellcol,cellrow);
	  if(b)
	  {
				if((m_row_hlight != cellrow || m_row_hlight < 0) && !m_bFreezHighlight)
				{

//					DebugMsg("MOUSEMOVE HLIGHT\n");
					m_row_hlight = cellrow;
					DrawGrid();
				}

	  }
	  else if(m_row_hlight >= 0 && !m_bFreezHighlight)
	  {
//		  DebugMsg("m_row_hlight = -1\n");
		  m_row_hlight = -1;
		  DrawGrid();
	  }
		

      if(CheckOptions(SGO_USERSIZE))
      {      
   
	
		


	

        if(m_bSizing)
        {
          int w = m_sizingLeft - LOWORD(lParam);

          if(m_columns[m_sizingCol].m_width > w+2)
          {
            m_columns[m_sizingCol].m_width -= w;
            m_sizingLeft -= w;
          }
  
          SetCursor(LoadCursor(NULL, IDC_SIZEWE));
          DrawGrid();
        }
        else if(yPos > HeadHeight() - m_rowHeight && yPos < HeadHeight())
        {
          int left  = m_columns[0].m_width + m_columns[m_leftCol].m_width;
          int col   = m_leftCol;
          while(left < (xPos) && col < RightColumn())
          {
            col++;
            left += m_columns[col].m_width;
          }  
  
          if(xPos > (left - 5) && xPos < (left + 10))
          {
            m_bSizeGrip = true;
            m_sizingCol = col;
            m_sizingLeft = left;
            SetCursor(LoadCursor(NULL, IDC_SIZEWE));
          }
          else
          {
            m_bSizeGrip = false;
            SetCursor(LoadCursor(NULL, IDC_ARROW));
          }
        }
        else
        {
          m_bSizeGrip = false;
          SetCursor(LoadCursor(NULL, IDC_ARROW));
        }
      }
      break;
    }
    
    case WM_VSCROLL:
    {
      
        bool redraw = true;
        m_si.cbSize = sizeof(SCROLLINFO);
        m_si.fMask  = SIF_ALL;
        ::GetScrollInfo(m_gridhWnd, SB_VERT, &m_si);

        switch(LOWORD(wParam))
        {
          case SB_LINEUP:
            if(m_si.nPos > m_si.nMin)
            {
                m_si.nPos--;
            }
            m_topRow  = m_si.nPos;
            break;

          case SB_LINEDOWN:
            m_bottomRow = BottomRow();
            if(m_bottomRow < m_rowCount - 1)
            {
              m_si.nPos++;
            }
            m_topRow  = m_si.nPos;
            break;

          case SB_PAGEUP:
          {
            int offset = m_row - TopRow();
            if((m_si.nPos - ((int)m_si.nPage - 2)) > m_si.nMin)
            {
              m_si.nPos -= ((int)m_si.nPage - 2);
            }
            else
            {
              m_si.nPos = m_si.nMin;
            }
            m_topRow  = m_si.nPos;
            m_row = m_topRow + offset;
            break;
          }
          case SB_PAGEDOWN:
          {
            int offset = m_row - TopRow();
            if(m_si.nPos + (int)m_si.nPage - 2 < m_si.nMax)
            {
              if(RowCount() - BottomRow() < (int)m_si.nPage)
              {
                m_si.nPos = RowCount() - (m_si.nPage - 1);
              }
              else
              {
                m_si.nPos += (int)m_si.nPage - 2;
              }
              m_topRow  = m_si.nPos;
              m_row = m_topRow + offset;
            }
            break;
          }

          case SB_TOP:
            m_si.nPos = m_si.nMin;
            m_topRow  = m_si.nPos;
            m_row     = 1;
            break;

          case SB_BOTTOM:
            m_si.nPos = RowCount() - (m_si.nPage - 1);
            m_topRow  = m_si.nPos;
            m_row = RowCount() - 1;
            break;

          case SB_THUMBPOSITION:
          case SB_THUMBTRACK:
            m_si.nPos = m_si.nTrackPos;
            m_topRow  = m_si.nPos;
            break;

          default:
            redraw = false;
            break;
        }

        if(redraw == true)
        {
          if(m_row < m_topRow) m_row = m_topRow;
          m_bottomRow = BottomRow();
          if(m_row > m_bottomRow) m_row = m_bottomRow;
          DrawGrid();
        }
      
      break;
    } // WM_VSCROLL
     
    case WM_HSCROLL:
    {
     
        bool redraw = true;
        m_si.cbSize = sizeof(SCROLLINFO);
        m_si.fMask  = SIF_ALL;
        ::GetScrollInfo(m_gridhWnd, SB_HORZ, &m_si);

        switch(LOWORD(wParam))
        {
          case SB_LINELEFT:
            if(m_si.nPos > m_si.nMin) m_si.nPos--;
            if(m_col >= RightColumn()) m_col = RightColumn() - 1;
            break;
            
          case SB_LINERIGHT:
            m_rightCol = RightColumn();
            if(m_rightCol < m_colCount - 1) m_si.nPos++;
            break;
            
          case SB_PAGELEFT:
          {
            int x = LeftColumn();
            // save offset of current column from left edge
            int offset = m_col - x;

            while(x < RightColumn() && LeftColumn() > 1)
            {
              m_leftCol--;
              m_si.nPos--;
            }

            // reset current column to same offset
            m_col = min((LeftColumn() + offset), (ColCount() - 1));

            break;
          }
           
          case SB_PAGERIGHT:
          {
            int i = RightColumn();

            // save offset of current column from left edge
            int offset = m_col - LeftColumn();

            if(i > ColCount() - ((int)m_si.nPage + 1))
            {
              i = ColCount() - (m_si.nPage - 1);
            }
            else if(i == m_leftCol && i < (m_colCount - 1))
            {
              i ++;
            }

            m_leftCol = i;
            m_si.nPos = m_leftCol;

            // reset current column to same offset
            m_col = min((LeftColumn() + offset), (ColCount() - 1));
            break;
          }

          case SB_LEFT:
            m_si.nPos = m_si.nMin;
            break;
            
          case SB_RIGHT:
            m_col = ColCount() - 1;
            m_leftCol = ColCount() - (m_si.nPage - 1);
            DrawGrid();
            SetScrollbars();
            m_si.nPos = m_si.nMax;
            
            break;
            
          case SB_THUMBPOSITION:
          case SB_THUMBTRACK:
            m_si.nPos = m_si.nTrackPos;
            break;
          
          default:
            redraw = false;
            break;    
        }
        if(redraw == true)
        {
			::SetScrollInfo(m_gridhWnd, SB_HORZ, &m_si, TRUE);
          m_leftCol = m_si.nPos;
          if(m_col < m_leftCol) m_col = m_leftCol;
          if(m_col >= ColCount()) m_col = ColCount() - 1;
          DrawGrid();
        }
    
      break;
    } // WM_HSCROLL
     
    case WM_PAINT:
    {
      PAINTSTRUCT ps;
      HDC         hdc = ::BeginPaint(hwnd, &ps);
      
      BitBlt(hdc, ps.rcPaint.left, ps.rcPaint.top,
        ps.rcPaint.right-ps.rcPaint.left,
        ps.rcPaint.bottom-ps.rcPaint.top,
        m_memdc,
        ps.rcPaint.left, ps.rcPaint.top,
        SRCCOPY);
    
      ::EndPaint(hwnd, &ps); 
      break;
    } // WM_PAINT
    
    case WM_SETFOCUS:
    {
      m_bFocused  = true;
      m_bGrayed   = false;            
      DrawGrid();
      break;
    }

    case WM_KILLFOCUS:
    {
      m_bFocused = false;

      if(CheckOptions(SGO_SHOWFOCUS))
        m_bGrayed = true;
        
         
      DrawGrid();
      break;
    }

    case WM_RBUTTONUP:    
    {
      int col, row;
      bool hit = HitTestCell(LOWORD(lParam), HIWORD(lParam), col, row);
	
      /*if(m_bEditing && col == m_col && row == m_row)
      {
        POINT pt;
        pt.x = LOWORD(lParam);
        pt.y = HIWORD(lParam);
        ::ClientToScreen(m_gridhWnd, &pt);
        TrackPopupMenu(m_hMenuPopup, TPM_RIGHTBUTTON, pt.x, pt.y, 0, m_gridhWnd, NULL);
      }
      else if(hit == true)
      {
        m_hMenuTip    = CreateMenu();
        m_hMenuTip2   = CreateMenu();
        AppendMenu(m_hMenuTip2, MF_STRING, 905, Cell(col, row));
        AppendMenu(m_hMenuTip, MF_POPUP, (UINT)m_hMenuTip2, "test");

        POINT pt;
        pt.x = LOWORD(lParam);
        pt.y = HIWORD(lParam);
        ::ClientToScreen(m_gridhWnd, &pt);
        TrackPopupMenu(m_hMenuTip2, TPM_RIGHTBUTTON, pt.x, pt.y, 0, m_gridhWnd, NULL);
        DestroyMenu(m_hMenuTip2);
        DestroyMenu(m_hMenuTip);
      }*/
      if(HitTestCell(LOWORD(lParam), HIWORD(lParam), col, row) == true)
      {
        LPARAM lParam = MAKELPARAM(col, row);
        WPARAM wParam = MAKEWPARAM(m_uID, SGN_RIGHTCLICK);
        ::SendMessage(::GetParent(m_gridhWnd), WM_COMMAND, wParam, lParam);
      }
      
      break;
    } // WM_RBUTTONUP
    
    case WM_LBUTTONDBLCLK: 
    {
      // start edit mode if grid edit option or column edit attribute set
	
      int col, row;
      if(HitTestCell(LOWORD(lParam), HIWORD(lParam), col, row) == true)
      {
/*#ifdef _DEBUG
		  DebugMsg("DBLCLICK row = %d, col = %d\n",row,col);
#endif*/
		  if(col == 0) m_rows[row].toogle_select();
		  else  
		  {
			  m_rows[row].toogle();
			  SetScrollbars();
		  }
		  DrawGrid();

        /*if(CheckOptions(SGO_EDITABLE) && !(GetColStyle(col) & SGA_NOEDIT))
        {
          InitEdit(col, row);
        }*/
      }
      break;
    } // WM_LBUTTONDBLCLK
    
    case WM_LBUTTONDOWN:
    {
      int   cellcol, cellrow;
      bool  b;
      b = HitTestCell((int)LOWORD(lParam),(int)HIWORD(lParam),cellcol,cellrow);
      
      if(m_bSizeGrip)
      {
        SetCursor(LoadCursor(NULL, IDC_SIZEWE));
        m_bSizing = true;
      }
      
     
      if(b == true)
      {
        SetColumn(cellcol);
        SetRow(cellrow);
      }
      ::SetFocus(m_gridhWnd);
      break;
    } // WM_LBUTTONDOWN
	


    case WM_LBUTTONUP:
    {
      if(m_bSizing)
      {
        m_bSizing = false;
      }
      DrawGrid();
      break;
    }
    
    case WM_DESTROY:
    {
      m_bWindowClosed = TRUE;
      /*if(m_hMenuTop) DestroyMenu(m_hMenuTop);
      if(m_hMenuPopup) DestroyMenu(m_hMenuPopup);*/

      if(m_memdc)
      {
        if(m_hOldBitmap)
        {
          DeleteObject(SelectObject(m_memdc, m_hOldBitmap));
        }
        DeleteDC(m_memdc);
      }
      PostQuitMessage(0);
      break;
    }
    
    case WM_SIZE:
    {
     

      ::GetClientRect(hwnd, &m_clRect);
      m_top    = m_clRect.top;
      m_left   = m_clRect.left;
      m_width  = m_clRect.right - m_clRect.left;
      m_height = m_clRect.bottom - m_clRect.top;
	  m_ScreenRows = (m_height/m_rowHeight)-1;

      m_bottomRow = BottomRow();
      int vr = (m_clRect.bottom / m_rowHeight)-1;
      
      while((m_row > m_topRow) && (m_row >= m_bottomRow))
      {
        m_topRow++;
        m_bottomRow = BottomRow();
      }

      while((m_col > m_leftCol) && (m_col > RightColumn()))
      {
        m_leftCol++;
      }

      m_rightCol  = RightColumn();
      m_bottomRow = BottomRow();

      if((m_bottomRow - m_topRow) < vr) 
      {
        int x = vr - (m_bottomRow - m_topRow);
        m_topRow = max(1, m_topRow - x); 
      }  

      SetScrollbars();
      DrawGrid();
      break;
    } // WM_SIZE
    
   
    
    case WM_KEYDOWN:
     
        switch(wParam)
        {
          case VK_UP:
          {
            // shift-up, move line up, cursor doesn't move
            if(GetKeyState(VK_SHIFT) < 0)
            {
              if(TopRow() > 1)
              {
                if(m_row > 1) m_row--;
                WPARAM wParam = MAKEWPARAM(SB_LINEUP, NULL);
                ::SendMessage(m_gridhWnd, WM_VSCROLL, wParam, (LPARAM)NULL);
              }
            }
            // ctrl-up, move page up, cursor doesn't move
            else if(GetKeyState(VK_CONTROL) < 0)
            {
              WPARAM wParam = MAKEWPARAM(SB_PAGEUP, NULL);
              ::SendMessage(m_gridhWnd, WM_VSCROLL, wParam, (LPARAM)NULL);
            }
            // up, moves cursor up, scrolls lines when at top
            else
            {
              if(m_row > TopRow())
              {
                m_row--;
                DrawGrid();
              }
              else if(TopRow() > 1) 
              {
                SetTopRow(TopRow() - 1);
                m_row = TopRow();
                DrawGrid();
              }
            }
            break;
		  }
            
          case VK_DOWN:
          {
            // shift-down, move line down, cursor doesn't move
            if(GetKeyState(VK_SHIFT) < 0)
            {
              if(BottomRow() < RowCount() - 1)
              {
                if(m_row < RowCount() - 1) m_row++;
                WPARAM wParam = MAKEWPARAM(SB_LINEDOWN, NULL);
                ::SendMessage(m_gridhWnd, WM_VSCROLL, wParam, (LPARAM)NULL);
              }
            }
            // ctrl-down, move page down, cursor doesn't move
            else if(GetKeyState(VK_CONTROL) < 0)
            {
              WPARAM wParam = MAKEWPARAM(SB_PAGEDOWN, NULL);
              ::SendMessage(m_gridhWnd, WM_VSCROLL, wParam, (LPARAM)NULL);
            }
            else
            {
              m_bottomRow = BottomRow();
              if(m_row < m_bottomRow)
              {
                m_row++;
                DrawGrid();
              }
              else if((m_topRow < m_rowCount - 1) && 
                      (m_bottomRow < (m_rowCount - 1))) 
              {
                m_topRow++;
                m_bottomRow = BottomRow();          
                if(m_row >= m_bottomRow) 
                  m_topRow++; 
                m_row++;
                DrawGrid();
              }
            }
            break;
          }
          
          case VK_RIGHT:
          {
            if(GetKeyState(VK_SHIFT) < 0)
            {
              if(RightColumn() < ColCount() - 1)
              {
                if(m_col < ColCount() - 1) m_col++;
                WPARAM wParam = MAKEWPARAM(SB_LINERIGHT, NULL);
                ::SendMessage(m_gridhWnd, WM_HSCROLL, wParam, (LPARAM)NULL);
              }
            }
            else if(GetKeyState(VK_CONTROL) < 0)
            {
              wParam = MAKEWPARAM(SB_PAGERIGHT, NULL);
              ::SendMessage(m_gridhWnd, WM_HSCROLL, wParam, (LPARAM)NULL);
            }
            else
            {
              m_rightCol = RightColumn();          
              if(m_col < m_rightCol)
              {
                m_col++;
                DrawGrid();
              }
              else if((m_leftCol < m_colCount - 1) && 
                      (m_rightCol < (m_colCount - 1))) 
              {
                m_leftCol++;
                m_rightCol = RightColumn();          
                if(m_col >= m_rightCol) 
                  m_leftCol++; 
                m_col++;
                DrawGrid();
              }
            
            break;
          }
            
          case VK_LEFT:
            // shift-left, move col left, cursor doesn't move
            if(GetKeyState(VK_SHIFT) < 0)
            {
              if(LeftColumn() > 1)
              {
                if(m_col > 1) m_col--;
                WPARAM wParam = MAKEWPARAM(SB_LINELEFT, NULL);
                ::SendMessage(m_gridhWnd, WM_HSCROLL, wParam, (LPARAM)NULL);
              }
            }
            // ctrl-left, move page left, cursor doesn't move
            else if(GetKeyState(VK_CONTROL) < 0)
            {
              WPARAM wParam = MAKEWPARAM(SB_PAGELEFT, NULL);
              ::SendMessage(m_gridhWnd, WM_HSCROLL, wParam, (LPARAM)NULL);
            }
            // left, moves cursor left, scrolls lines when at left edge
            else
            {
              if(m_col > LeftColumn())
              {
                m_col--;
                DrawGrid();
              }
              else if(LeftColumn() > 1)
              {
                SetLeftCol(LeftColumn() - 1);
                m_col = LeftColumn();
                DrawGrid();
              }
            }
            break;
          
          case VK_PRIOR:
          {
            WPARAM wParam = MAKEWPARAM(SB_PAGEUP, NULL);
            ::SendMessage(m_gridhWnd, WM_VSCROLL, wParam, (LPARAM)NULL);

            break;
          }
           
          case VK_NEXT:
          {
            WPARAM wParam = MAKEWPARAM(SB_PAGEDOWN, NULL);
            ::SendMessage(m_gridhWnd, WM_VSCROLL, wParam, (LPARAM)NULL);

            break;
          }
           
          case VK_HOME:
          {
            if(GetKeyState(VK_SHIFT) < 0)
            {
              WPARAM wParam = MAKEWPARAM(SB_TOP, NULL);
              ::SendMessage(m_gridhWnd, WM_VSCROLL, wParam, (LPARAM)NULL);
            }
            else
            {
              m_col = 1;
              SetLeftCol(1);
              if(GetKeyState(VK_CONTROL) < 0)
              {
                m_row = 1;
                SetTopRow(1);
              }
              DrawGrid();
            }
            break;
          }
          
          case VK_END:
          {
            if(GetKeyState(VK_SHIFT) < 0)
            {
              WPARAM wParam = MAKEWPARAM(SB_BOTTOM, NULL);
              ::SendMessage(m_gridhWnd, WM_VSCROLL, wParam, (LPARAM)NULL);
            }
            else
              {
              int c = m_colCount - 1;
              int w = m_columns[c].m_width;
              m_col = c;
  
              while(w < m_width && c > 1)
              {
                --c;
                w += m_columns[c].m_width;
              }
              SetLeftCol(c + 2);
  
              if(GetKeyState(VK_CONTROL) < 0)
              {
                WPARAM wParam = MAKEWPARAM(SB_BOTTOM, NULL);
                ::SendMessage(m_gridhWnd, WM_VSCROLL, wParam, (LPARAM)NULL);
              }
              DrawGrid();
            }
            break;
          }      
          
          case VK_RETURN:
          {
            /*if(CheckOptions(SGO_EDITABLE) &&
                            !(GetColStyle(m_col) & SGA_NOEDIT))
            {
              InitEdit(m_col, m_row);
            }*/
            break;
          }
          
          default:
            break;
        }
      break;
    } // WM_KEYDOWN

    /*default:
		return ::DefWindowProc(hwnd, uMsg, wParam, lParam);*/
  }
   return ::DefWindowProc(hwnd, uMsg, wParam, lParam);
};


