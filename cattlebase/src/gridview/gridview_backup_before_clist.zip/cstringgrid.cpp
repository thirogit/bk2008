/******************************************************************************
* File Name:   cstringgrid.cpp
* Author:      D. Van Leer
* Date:        05/23/03
* Copyright:   2003 D. Van Leer
* Description: stringgrid class main functions
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
******************************************************************************/

#include "stdafx.h"
#include "cstringgrid.h"
#include "..\VisualFX\VisualFx.h"


#ifndef GRADIENT_FILL_RECT_H
  #define GRADIENT_FILL_RECT_H  0
#endif
#ifndef GRADIENT_FILL_RECT_V
  #define GRADIENT_FILL_RECT_V  1
#endif

using namespace std;


IMPLEMENT_DYNCREATE(CStringGrid,  CScrollView)

BEGIN_MESSAGE_MAP(CStringGrid, CScrollView)
	
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_PAINT()
	ON_WM_SETFOCUS()
	//ON_WM_CONTEXTMENU()

END_MESSAGE_MAP()


#ifdef _DEBUG
void CStringGrid::AssertValid() const
{
	CScrollView::AssertValid();
}

void CStringGrid::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG
/*
void CStringGrid::OnContextMenu(CWnd *pWnd,CPoint pos)
{

	int r,c;
	ScreenToClient(&pos);
//	DebugMsg("pos = x = %d,y = %d\n",pos.x,pos.y);
	if(HitTestCell(pos.x,pos.y,c,r))
	{
		CWnd *parent = GetParent();
		parent->SendMessage(WM_TABCONTEXT,(WPARAM)0,MAKELPARAM(r,c));
	}
	
	//CScrollView::OnContextMenu(pWnd,pos);
}*/





int CStringGrid::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CScrollView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	   RECT rect;    // rect for initial stringgrid height & width
       SetRect(&rect, 0, 0, 100, 100);
	   Create(CScrollView::m_hWnd, 0, &rect, 0, 0);//WS_EX_CLIENTEDGE);
	   //::ShowWindow(m_gridhWnd,0);
	   return 0;
}

void CStringGrid::OnDraw(CDC* pDC)
{
	//CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

BOOL CStringGrid::PreCreateWindow(CREATESTRUCT& cs) 
{
	return Register(cs.hInstance) && CScrollView::PreCreateWindow(cs);
}


void CStringGrid::OnPaint() 
{
	CPaintDC dc1(this); // device context for painting
}


void CStringGrid::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();
}


void CStringGrid::OnSize(UINT nType, int cx, int cy)
{
	CScrollView::OnSize(nType, cx, cy);
	RECT rect;
      if(Handle())
      {
		  ::ShowWindow(Handle(), SW_SHOW);

        GetClientRect(&rect);
        ::MoveWindow(Handle(), rect.left,
                                rect.top ,
                                rect.right,
                                rect.bottom,
                                TRUE);
	  }

}
void CStringGrid::OnSetFocus(CWnd* pOldWnd) 
{
	CScrollView::OnSetFocus(pOldWnd);
	HWND hFocus = Handle();

	if(hFocus) ::SetFocus(hFocus);
}



// static member to indicate window class registered
bool CStringGrid::sg_Registered;

ATOM CStringGrid::Register(HINSTANCE hinst)
{
  if(sg_Registered != true)       // if not already registered 
  {
    WNDCLASSEX wincl;

    sg_Registered       = true;   // set flag
    m_hInst             = hinst;  // set instance handle

    // set up and register classs
    wincl.cbSize        = sizeof(WNDCLASSEX);
    wincl.style         = CS_DBLCLKS | CS_OWNDC;
    wincl.lpfnWndProc   = CStringGrid::stWinMsgHandler;	
    wincl.cbClsExtra    = 0;
    wincl.cbWndExtra    = 0;
    wincl.hInstance     = m_hInst;
    wincl.hIcon         = NULL;
    wincl.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wincl.hbrBackground = NULL;
    wincl.lpszMenuName  = NULL;
    wincl.lpszClassName = "HP_StringGridClass";
    wincl.hIconSm       = NULL;
  
    sg_Registered = (RegisterClassEx(&wincl) != 0);
	return sg_Registered;
	
  }
  else
  {

    return 1;
  }
}
//-----------------------------------------------------------------------------
// Function: CStringGrid
// Use:      constructor
// Args:     HINSTANCE hInst - application instance
//           int       cols  - number of columns
//           int       rows  - number of rows
//-----------------------------------------------------------------------------
CStringGrid::CStringGrid(int cols, int rows) :
  m_hInst         (NULL),
  m_gridhWnd          (NULL),

  m_top           (0),
  m_left          (0),
  m_width         (0),
  m_height        (0),
  m_ScreenRows    (0),
  m_row_hlight    (-1),
  m_col           (1),
  m_row           (1),
  m_colCount      (minmax(0, cols, MAX_COLS)),
  m_rowCount      (minmax(0, rows, MAX_ROWS)),
  m_rowHeight     (25),
  m_titleHeight   (20),
  m_leftCol       (1),
  m_rightCol      (1),
  m_topRow        (1),
  m_bottomRow     (1),

  m_numRowStart   (1),
  m_numRowStep    (1),

 
  m_bFocused      (false),
  m_bGrayed       (true),

  m_dwOptions     (SGO_VISIBLE      |
                   SGO_EDITABLE     |
                   SGO_CELLSEL      |
                   SGO_SCROLLDOT    |
                   SGO_FIXEDCOL     |
                   SGO_FIXEDROW     |
                   SGO_SHOWFOCUS    |
                   0),

  m_dwExStyle     (0),
  m_dwStyle       (WS_CHILD         | 
                   WS_CLIPSIBLINGS  | 
                   WS_VISIBLE       | 
                   WS_CLIPCHILDREN  |
                   WS_VSCROLL       |
                   WS_HSCROLL       |
                   0),
                   
  m_titleString   (""),
  m_bSizing(false),
  m_bFreezHighlight(false),
  m_VisRows(m_rowCount)
{
  SetRectEmpty(&m_clRect);
  int i;

//  m_cells.resize((m_colCount * m_rowCount), "00");
//  m_cells.resize((m_colCount * m_rowCount));
  m_rows.resize(rows);
  for(i=0;i<rows;i++) m_rows[i].m_cells.resize(cols);

  // set default colors
  // 16 text colors
  m_colors[SGC_TEXT_0]      = GetSysColor(COLOR_WINDOWTEXT);
  m_colors[SGC_TEXT_1]      = RGB(  0,   0, 255);
  m_colors[SGC_TEXT_2]      = RGB(  0, 128,   0); 
  m_colors[SGC_TEXT_3]      = RGB(  0, 180, 180);
  m_colors[SGC_TEXT_4]      = RGB(255,   0,   0); 
  m_colors[SGC_TEXT_5]      = RGB(180,   0, 180);
  m_colors[SGC_TEXT_6]      = RGB(128,  64,   0); 
  m_colors[SGC_TEXT_7]      = RGB(220, 220, 220);
  m_colors[SGC_TEXT_8]      = RGB(128, 128, 128); 
  m_colors[SGC_TEXT_9]      = RGB(180, 180, 255);
  m_colors[SGC_TEXT_A]      = RGB(180, 255, 180); 
  m_colors[SGC_TEXT_B]      = RGB(128, 255, 255);
  m_colors[SGC_TEXT_C]      = RGB(255, 180, 180); 
  m_colors[SGC_TEXT_D]      = RGB(255, 128, 255);
  m_colors[SGC_TEXT_E]      = RGB(255, 255,   0); 
  m_colors[SGC_TEXT_F]      = RGB(255, 255, 255);
  // 4 column colors
  m_colors[SGC_COLUMN_1]    = RGB(240, 255, 255);
  m_colors[SGC_COLUMN_2]    = RGB(255, 240, 255);
  m_colors[SGC_COLUMN_3]    = RGB(255, 255, 240);
  m_colors[SGC_COLUMN_4]    = RGB(240, 255, 240);
  
  // other colors                              
  m_colors[SGC_GRIDBKGND]   = RGB(0xFF, 0xFF, 0xFF);
  m_colors[SGC_CELLBKGND]   = GetSysColor(COLOR_WINDOW);
  m_colors[SGC_EDITBKGND]   = RGB(250, 255, 255);
  m_colors[SGC_FXDCELL]     = RGB(0x90,0xC8,0x90); //GetSysColor(COLOR_BTNFACE);
  m_colors[SGC_SELCELL]     = GetSysColor(COLOR_INFOBK);

  m_colors[SGC_FXDCOLTEXT]  = GetSysColor(COLOR_BTNTEXT);
  m_colors[SGC_FXDROWTEXT]  = GetSysColor(COLOR_BTNTEXT);
  m_colors[SGC_TITLETEXT]   = RGB(0, 0, 200);
  m_colors[SGC_EDITTEXT]    = RGB(  0,   0,   0);
  m_colors[SGC_SELTEXT]     = GetSysColor(COLOR_INFOTEXT);
  m_colors[SGC_GRAYTEXT]    = GetSysColor(COLOR_GRAYTEXT);

  m_colors[SGC_SELBORDER]   = GetSysColor(COLOR_INFOTEXT);
  m_colors[SGC_EDITBORDER]  = RGB(  0,   0, 255);
  m_colors[SGC_GRIDLINE]    = RGB(0, 0, 0);
  m_colors[SGC_SCROLLDOT]   = RGB( 50,  50,  50);
  m_colors[SGC_ODDROWBARS]  = RGB(230, 255, 240);

  m_colors[SGC_GRADTOP]     = RGB(255, 255, 255);
  m_colors[SGC_GRADBOTTOM]  = RGB(204, 204, 236);


  // set default column widths
  m_columns.push_back(ColumnType(50));  // fixed column 50

  for(i = 1; i < m_colCount; i++)   // rest of columns use
    m_columns.push_back(ColumnType());  // default of 100

  // set default fonts
  memset(&m_fxFont, 0, sizeof(LOGFONT));
  m_fxFont.lfHeight            = 12L;
  m_fxFont.lfWeight            = 0L;
  m_fxFont.lfQuality           = PROOF_QUALITY;
  m_fxFont.lfCharSet	       = DEFAULT_CHARSET;
  
  lstrcpy(m_fxFont.lfFaceName, "Verdana");

  memset(&m_cellFont, 0, sizeof(LOGFONT));
  m_cellFont.lfHeight          = 12L;
  m_cellFont.lfWeight          = 200L;
  m_cellFont.lfQuality         = PROOF_QUALITY;
  lstrcpy(m_cellFont.lfFaceName, "courier new");

  memset(&m_titleFont, 0, sizeof(LOGFONT));
  m_titleFont.lfHeight         = 18L;
  m_titleFont.lfWeight         = FW_SEMIBOLD;
  m_titleFont.lfQuality        = PROOF_QUALITY;
  m_titleFont.lfPitchAndFamily = FIXED_PITCH | FF_SWISS;
  lstrcpy(m_titleFont.lfFaceName, "ms sans serif");

  memset(&m_editFont, 0, sizeof(LOGFONT));
  m_editFont.lfHeight          = 12L;
  m_editFont.lfWeight          = 200L;
  m_editFont.lfQuality         = PROOF_QUALITY;
  m_editFont.lfPitchAndFamily  = FIXED_PITCH | FF_MODERN;
  lstrcpy(m_editFont.lfFaceName, "courier");

  m_imgList.DeleteImageList();
	 if( m_SelectImage.LoadBitmap( IDB_SELECTICON ) ) 
	 {
		m_SelectImage.GetObject( sizeof( m_SelectBitmap ) , &m_SelectBitmap );

		if( m_imgList.Create( m_SelectBitmap.bmWidth , m_SelectBitmap.bmWidth , ILC_COLORDDB | ILC_MASK ,  1 , 1 ) ) 
		{	
			m_imgList.Add( &m_SelectImage , RGB(255,0,255));
		}

	 }

  
 

};

void CStringGrid::SetFont(SGF_ENUM font, LOGFONT lf)
{
  if(font == SGF_FIXEDCELLS)
  {
    m_fxFont = lf;
  }
  else if(font == SGF_CELLS)
  {
    m_cellFont = lf;
  }
  else if(font == SGF_TITLE)
  {
    m_titleFont = lf;
    return;   // skip resize
  }
  else if(font == SGF_EDIT)
  {
    m_editFont = lf;
    return;   // skip resize
  }

  // resize cells
  if(CheckOptions(SGO_AUTOSIZE))
  {
    for(int c = 0; c < m_colCount; ++c)
      AutoSizeCol(c);
  }

}

/******************************************************************************
* Function: ~CStringGrid
* Use:      Destructor
******************************************************************************/
CStringGrid::~CStringGrid()
{
//	if(m_gridhWnd  != NULL) ::DestroyWindow(m_gridhWnd);
}
/******************************************************************************
* Function: Create
* Use:      creates window
* Args:     HWND hParent    - handle of parent window
*           UINT uId        - identifier
*           RECT* rect      - window coordinates
*           DWORD dwStyles  - window style 
******************************************************************************/
BOOL CStringGrid::Create(HWND hParent, UINT uID, RECT* rect,
                          DWORD dwStyle, DWORD dwExStyle)
{ 
  if(dwStyle   != 0) m_dwStyle   = dwStyle;
  if(dwExStyle != 0) m_dwExStyle = dwExStyle;
      
  m_top     = rect->top;
  m_left    = rect->left;
  m_width   = rect->right - rect->left;
  m_height  = rect->bottom - rect->top;
  m_ScreenRows = (m_height/m_rowHeight)-1;
  m_uID     = uID;     
  
	// send the 'this' pointer as the window creation parameter
	m_gridhWnd = CreateWindowEx(
            m_dwExStyle,
            TEXT("HP_StringGridClass"),
            TEXT("StringGrid"),  
            m_dwStyle, 
            m_left, m_top, m_width, m_height,
            hParent, 
            (HMENU) uID, 
            m_hInst, 
		        (void *)this
          );

	return (m_gridhWnd != NULL);
}

/******************************************************************************
* static message handler
******************************************************************************/
LRESULT CALLBACK 
CStringGrid::stWinMsgHandler(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CStringGrid* pWnd;

	if (uMsg == WM_NCCREATE)
	{
		// get the pointer to the window from lpCreateParams 
    // which was set in CreateWindow
		SetWindowLong(hwnd, GWL_USERDATA, 
                  (long)((LPCREATESTRUCT(lParam))->lpCreateParams));
	}

	// get the pointer to the window
	pWnd = GetObjectFromWindow(hwnd);

	// if we have the pointer, go to the message handler of the window
	// else, use DefWindowProc
	if (pWnd)
		return pWnd->WinMsgHandler(hwnd, uMsg, wParam, lParam);
	else
		return ::DefWindowProc(hwnd, uMsg, wParam, lParam);
}

WORD CStringGrid::GetCellStyle(int col, int row)
{
  if(CellExists(col, row))
    //return m_cells[m_colCount * row + col].m_style;
	return m_rows[row].m_cells[col].m_style;
  else
    return SGA_PLAIN;
}

void CStringGrid::SetCellStyle(int col, int row, WORD style)
{
  if(CellExists(col, row))
    //m_cells[m_colCount * row + col].m_style = style;
	m_rows[row].m_cells[col].m_style = style;
}

void CStringGrid::SetCellColor(int col, int row, COLORREF color)
{
  if(CellExists(col, row))
//    m_cells[m_colCount * row + col].m_color = color;
m_rows[row].m_cells[col].m_color = color;
}

// set column color
void CStringGrid::SetColColor(int col, SGC_ENUM color)
{
  if(0 < col && col < m_colCount)
  {
//  m_columns[col].m_color = color;
  }
}

// get column color
int CStringGrid::GetColColor(int col)
{
 /* if(0 < col && col < m_colCount)
  {
  //return m_columns[col].m_color;
  }
  else*/
   
	 return SGC_CELLBKGND;
}

// set column style
void CStringGrid::SetColStyle(int col, WORD style)
{
 /* if(0 <= col && col < m_colCount)
  {
//  m_columns[col].m_style = style;
  }*/


}

// get column style
WORD CStringGrid::GetColStyle(int col)
{
 /* if(0 <= col && col < m_colCount)
  {
//  return m_columns[col].m_style;
  }
  else*/
    return SGA_ALIGNCENTER;
}

/************************************************
* set cell string 
************************************************/
bool CStringGrid::SetCell(int col, int row, string s)
{
  if(CellExists(col, row))
  {
   // m_cells[m_colCount * row + col].m_string = s;
	  m_rows[row].m_cells[col].m_string = s;

    if(CheckOptions(SGO_AUTOSIZE))
      AutoSizeCol(col);

    return true;
  }
  else
    return false;
}

LPCTSTR CStringGrid::Cell(int col, int row)
{
  if(CellExists(col, row))
  {
    //return (LPCTSTR) m_cells[m_colCount * row + col].m_string.c_str();
	  return (LPCTSTR) m_rows[row].m_cells[col].m_string.c_str();
  }
  else
    return "";
}

string CStringGrid::CellString(int col, int row)
{
  if(CellExists(col, row))
  {
    //return m_cells[m_colCount * row + col].m_string;
	  return m_rows[row].m_cells[col].m_string;
  }
  else
    return "";
}

/******************************************************************************
* Function: GetCellRect
* Use:      gets rectangle with cell coordinates in rc
*           returns false if cell not visible
* Args:     int c - colunn
*           int r - row
*
******************************************************************************/
bool CStringGrid::GetCellRect(int c, int r, RECT& rc)
{
  if(c < m_leftCol || c >= m_colCount || r < m_topRow || r >= m_rowCount)
    return false;

  int top = HeadHeight() + m_rowHeight * (r - m_topRow);
  if(top >= m_height) return false;

  int left = m_columns[0].m_width;
  for(int i = m_leftCol; i < c; i++)
    left += m_columns[i].m_width;

  if(left >= m_width) return false;

  rc.left    = left + 1;
  rc.right   = left + m_columns[c].m_width;
  rc.top     = top + 1;
  rc.bottom  = top + m_rowHeight;
  
  return true;
}

/******************************************************************************
* Function: HitTestCell
* Use:      finds which cell point (x, y) is in 
* Args:     int x   - x coord of point to test
*           int y   - y coord of point to test
*           int& c  - reference to variable to receive column point is in
*           int& r  - reference to variable to receive row point is in
******************************************************************************/
bool CStringGrid::HitTestCell(int x, int y, int& c, int& r)
{
	int col,left;

	if( x > m_width || y < HeadHeight() || y > m_height)
    return false;
  
	if(x < m_columns[0].m_width)
		col = 0;
	else
	{


	  left  = m_columns[0].m_width  + m_columns[m_leftCol].m_width;
	  col   = m_leftCol;
	  while(left < x && col < RightColumn() + 1)
	  {
		col++;
		left += m_columns[col].m_width;
	  }  
	}

  int row = m_topRow;
  int top =  HeadHeight() + ((int)m_rows[row].visible)*(m_rowHeight + m_rows[row].CloakHeight());
  
//#ifdef _DEBUG
 // DebugMsg("y= %d, top = %d,row = %d\n",y,top,row);
//#endif
  while(top < y && row < m_bottomRow + 1)
  {
	row++;
	top += ((int)m_rows[row].visible)*(m_rowHeight+m_rows[row].CloakHeight());
	
/*	
#ifdef _DEBUG
	DebugMsg("||y= %d, top = %d,row = %d\n",y,top,row);
#endif*/
  }
  
  if((col < RightColumn() + 1) && (row < BottomRow() + 1))
  {
    c = col;
    r = row;
    return true;
  }
  else
  {
    c = m_col;
    r = m_row;
    return false;   
  }
}

/******************************************************************************
* Function: BtnCell
* Use:      Draws cells with 3D button look
* Args:     RECT rc - rectangle with cell coordinates
******************************************************************************/
void CStringGrid::BtnCell(RECT rc)
{
//  HGDIOBJ oldPen;
  HBRUSH br = CreateSolidBrush(m_colors[SGC_FXDCELL]);
//  COLORREF gradcolor;
  // fill cell
  //rc.left++;
  rc.top++; 
  
  //  if not xp style, solid fill
  //if(!CheckOptions(SGO_XPSTYLE))
 // {
    FillRect(m_memdc, &rc, br);
 // }
 //  else gradient fill
  //else
  //{
//    TRIVERTEX verts[2];
  //  GRADIENT_RECT gr  = {0, 1};

  /*  gradcolor         = m_colors[SGC_GRADTOP];
    verts[0].x        = rc.left;
    verts[0].y        = rc.top;
    verts[0].Red      = (WORD) ((gradcolor & 0x000000FF) << 8);
    verts[0].Green    = (WORD) (gradcolor & 0x0000FF00);       
    verts[0].Blue     = (WORD) ((gradcolor & 0x00FF0000) >> 8);
    verts[0].Alpha    = 0;
    
    gradcolor         = m_colors[SGC_GRADBOTTOM];
    verts[1].x        = rc.right;
    verts[1].y        = rc.bottom;
    verts[1].Red      = (WORD) ((gradcolor & 0x000000FF) << 8);
    verts[1].Green    = (WORD) (gradcolor & 0x0000FF00);       
    verts[1].Blue     = (WORD) ((gradcolor & 0x00FF0000) >> 8);
    verts[1].Alpha    = 0;
    
    if(rc.top > HeadHeight() && CheckOptions(SGO_XPHORZ)
        && rc.left < m_columns[0].m_width)
    GradientFill(m_memdc, verts, 2, &gr, 1, GRADIENT_FILL_RECT_H);
    else
    GradientFill(m_memdc, verts, 2, &gr, 1, GRADIENT_FILL_RECT_V);*/
  //}
  // adjust rect
  //rc.right--;
 // rc.bottom--;

  // draw hilights
 /* oldPen = SelectObject(m_memdc, CreatePen(PS_SOLID, 0, 
                        GetSysColor(COLOR_BTNHILIGHT)));
  MoveToEx(m_memdc, rc.left, rc.bottom, NULL);
  LineTo(m_memdc, rc.left, rc.top);
  LineTo(m_memdc, rc.right, rc.top);

  //draw shadows
  DeleteObject(SelectObject(m_memdc, CreatePen(PS_SOLID, 0, 
                            GetSysColor(COLOR_BTNSHADOW))));
  LineTo(m_memdc, rc.right, rc.bottom);
  LineTo(m_memdc, rc.left, rc.bottom);
    
  DeleteObject(SelectObject(m_memdc, oldPen));*/
  DeleteObject(br);
}

int CStringGrid::AvgColWidth()
{
  int sum = 0;
  if(m_colCount > 0)
  {
    for(int i = 0; i < m_colCount; i++)
    {
      sum += m_columns[i].m_width;
    }
    return (sum / m_colCount);
  }
  return 1;
}

int CStringGrid::GetColWidth(int col)
{
 
  if(col >= 0 && col < m_colCount)
  {
     return m_columns[col].m_width;
   }
  return 0;

}



/******************************************************************************
* Function: AddOptions
* Use:      Sets option flags
* Args:     DWORD options - option flags to be set, can be ORed together
******************************************************************************/
void CStringGrid::AddOptions(DWORD options)
{
  // if autosize, turn off usersize and vice-versa 
  if(options & SGO_AUTOSIZE)
  {
    m_dwOptions = m_dwOptions & ~SGO_USERSIZE;
    options = options & ~SGO_USERSIZE;
  }
  else if(options & SGO_USERSIZE)
  {
    m_dwOptions = m_dwOptions & ~SGO_AUTOSIZE;
    options = options & ~SGO_AUTOSIZE;
  }
    
  m_dwOptions = m_dwOptions | options;
}

/******************************************************************************
* Function: DelOptions
* Use:      Clears option flags
* Args:     DWORD options - option flags to be cleared, can be ORed together
******************************************************************************/
void CStringGrid::DelOptions(DWORD options)
{
  m_dwOptions = m_dwOptions & ~options;
}

/******************************************************************************
* Function: CheckOptions
* Use:      Checks if option flags are set
* Args:     DWORD options - option flags to be checked, can be ORed together
* Returns:  bool - true if flags set, false if not set
******************************************************************************/
bool CStringGrid::CheckOptions(DWORD options)
{
  return ((m_dwOptions & options) == options) ? true : false;
}

/******************************************************************************
* Function: SetOptions
* Use:      Sets options
* Args:     DWORD options - option flags to be set, can be ORed together
******************************************************************************/
void CStringGrid::SetOptions(DWORD options)
{
  // disallow usersize if autosize 
  if(options & SGO_AUTOSIZE)
    options = options & ~SGO_USERSIZE;
    
  m_dwOptions = options;
}

/******************************************************************************
* Function: SetColor
* Use:      Sets indexed color in color table
* Args:     DWORD index - index of color to set
* Returns:  COLORREF - old color, or SGC_ERROR if index out of range
******************************************************************************/
COLORREF CStringGrid::SetColor(DWORD index, COLORREF color)
{
  if(index < NUM_COLORS)
  {
    COLORREF temp   = m_colors[index];
    m_colors[index] = color;
    return temp;
  }
  else
  {
    return SGC_ERROR;
  }
}

/******************************************************************************
* Function: GetColor
* Use:      Gets indexed color from color table
* Args:     DWORD index - index of color to get
* Returns:  COLORREF - color, or SGC_ERROR if index out of range
******************************************************************************/
COLORREF CStringGrid::GetColor(DWORD index)
{
  if(index < NUM_COLORS)
  {
    return m_colors[index];
  }
  else
  {
    return SGC_ERROR;
  }
}

/******************************************************************************
* Function: GetCellColor
* Use:      Gets text color of cell(col, row)
* Args:     int col - column of cell
*           int row - row of cell  
* Returns:  COLORREF - text color for cell, defaults to first color in table
******************************************************************************/
COLORREF CStringGrid::GetCellColor(int col, int row)
{
  if(col < m_colCount && row < m_rowCount && col > 0 && row > 0)
  {
    //return m_colors[m_cells[m_colCount * row + col].m_color];
	  return m_colors[m_rows[row].m_cells[col].m_color];
  }
  else
    return m_colors[SGC_TEXT_0];
}

bool CStringGrid::ResizeGrid(int cols, int rows)
{
  bool flag = false;
  
  if(cols < ColCount() && cols > 1)
  {
    for(int c = ColCount(); c > cols; c--)
    {
      DeleteCol(cols);
    }
    flag = true;
  }
  else if(cols > ColCount() && cols <= MAX_COLS)
  {
    int cc = ColCount();
    for(int c = cc; c < cols; c++)
    {
      InsertCol(cc, 100);
    }
    flag = true;
  }

  if(rows < RowCount() /*&& rows > 1*/)
  {
    for(int r = RowCount(); r > rows; r--)
    {		
		DeleteRow(rows);
    }
    flag = true;
  }
  else if(rows > RowCount() && rows <= MAX_ROWS)
  {
    int rc = RowCount();
    for(int r = rc; r < rows; r++)
    {
      InsertRow(rc);
    }
    flag = true;
  }

  if(flag == false)
  {
    return false;
  }
  else
  {
    m_col = 1;
    m_row = 1;
    m_topRow = 1;
    m_leftCol = 1;
    SetScrollbars();
    return true;
  }
}

/*! Clears all cells and redraws grid. \n Does not change size of grid. */
void CStringGrid::ClearGrid()
{
  for(int c = 0; c < ColCount(); c++)
    for(int r = 0; r < RowCount(); r++)
      SetCell(c, r, "");
      
  DrawGrid();
}  

void CStringGrid::SetScrollbars()
{
	int cH = 0,i;//,hidRows = 0;

	::GetClientRect(m_gridhWnd, &m_clRect);
  m_si.cbSize = sizeof(SCROLLINFO);
  m_si.fMask  = 
              SIF_RANGE | 
              SIF_PAGE  |
              SIF_POS   |
              0;
  m_si.nMin   = 1;
  m_si.nMax   = m_VisRows;


  for(i=m_topRow;i<=m_bottomRow;i++) 
  {
	  if(m_rows[i].visible) cH += m_rows[i].CloakHeight();
	 // else hidRows++;
  }

  m_si.nPage  = min(m_VisRows,((m_clRect.bottom - TitleHeight() - cH) / m_rowHeight));
  
  
  
  m_si.nPos   = m_topRow;
  ::SetScrollInfo(m_gridhWnd, SB_VERT, &m_si, TRUE);

  
  int c = ColCount() - 1;
  int x = m_columns[0].m_width;
  while(x < (m_clRect.right - m_clRect.left) && c >= 0){
    x += m_columns[c].m_width;
    c--;
  }
  if(c == -1) m_leftCol = 1;

  m_si.nMin   = 1;
  m_si.nPage  = ColCount() - (c + 1);
  m_si.nMax   = m_colCount;
  m_si.nPos   = m_leftCol;
  ::SetScrollInfo(m_gridhWnd, SB_HORZ, &m_si, TRUE);
}

void CStringGrid::NumberRows(int start, int step)
{
  char  buf[16];
  for(int i = 1; i < RowCount(); i++)
  {
    wsprintf(buf, "%d", step * (i - 1) + start);
    SetCell(0, i, (string)buf);
  }
}

void CStringGrid::SetNumRowParams(int start, int step)
{
  m_numRowStart = start;
  m_numRowStep = step;
}

int CStringGrid::HeadHeight()
{
  // add title and row heights dependant on option settings
  int height = ((CheckOptions(SGO_TITLE))     ? m_titleHeight : 0) +
               ((CheckOptions(SGO_FIXEDROW))  ? m_rowHeight   : 0);
  
  return height;
}

int CStringGrid::TitleHeight()
{
  return (CheckOptions(SGO_TITLE)) ? m_titleHeight : 0;
}

void CStringGrid::SetTitleString(string s)
{
  m_titleString = s;
}

string CStringGrid::GetTitleString()
{
  return m_titleString;
}


/*
bool CStringGrid::SetSize(int rows,int cols)
{

if(!(rows > 0 && cols > 0)) return FALSE;
	
	m_colCount  =   (minmax(1, cols, MAX_COLS));
    m_rowCount  =   (minmax(1, rows, MAX_ROWS));

	 m_rows.resize(m_rowCount);
	 for(int i=0;i<m_rowCount;i++) m_rows[i].m_cells.resize(m_colCount);
	  m_columns.resize(m_colCount,ColumnType());



	//if(m_row_hlight > rows) m_row_hlight = rows-1;
	//if(m_col > cols) m_col = cols-1;
	//if(m_row > rows) m_row = rows-1;

return TRUE;

}*/



void  CStringGrid::FreezHighlight(void)
{
//	DebugMsg("Freezing...\n");
	m_bFreezHighlight = true;
}


void CStringGrid::UnFreezHighlight(void)
{
	m_bFreezHighlight = false;
}


void* CStringGrid::GetHighlightedRowPtr(void)
{
	if(m_row_hlight > 0) return m_rows[m_row_hlight].userptr;
	return NULL;
}

bool  CStringGrid::SetRowCloakSize(int row,int cloakrows,int cloakcols)
{
	if(row >= 0 && row < m_rowCount) return m_rows[row].SetCloakSize(cloakrows,cloakcols);
	return false;

};


void CStringGrid::SetRowVisible(int iRow,bool bVis)
{
//	DebugMsg("iRow = %d B bottom = %d, top = %d\n",iRow,m_bottomRow,m_topRow);
	if(iRow > 0 && iRow < RowCount())
	{
		if((iRow <= m_bottomRow && iRow >=m_topRow) || ((m_VisRows-1) < m_ScreenRows)) 
		{
			
			if(!bVis && m_rows[iRow].visible)
			{
				if((m_bottomRow+1) < RowCount())
					m_bottomRow++;
				else
				{
					if((m_topRow-1) > 0) m_topRow--;
				}
			

			} else if (!m_rows[iRow].visible)
			{

				if((m_VisRows > m_ScreenRows) )
					m_bottomRow--;
				else if ((m_bottomRow+1) < RowCount()) m_bottomRow++;
				
			}



		}

		if(m_rows[iRow].visible != bVis) m_VisRows += ( bVis ? 1 : (-1));

		m_rows[iRow].visible = bVis;
			
			//DebugMsg("A bottom = %d, top = %d\n",m_bottomRow,m_topRow);
		}
}

void CStringGrid::ToggleVisible(int iRow)
{

	VERIFY(iRow > 0 && iRow < m_rowCount);
		SetRowVisible(iRow,!GetRowVisible(iRow));

}

bool  CStringGrid::SetRowColor(int row,COLORREF color)
{
	if(row >= 0 && row < m_rowCount) m_rows[row].m_color = color;
    else return false;

	return true;

};

RowType *CStringGrid::GetRowPtr(int row)
{
if(row >= 0 && row < m_rowCount) return &m_rows[row];
return NULL;
}

