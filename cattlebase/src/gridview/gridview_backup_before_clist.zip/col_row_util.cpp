/******************************************************************************
* File Name:    col_row_util.cpp
* Author:       D. Van Leer
* Date:         11/01/03
* Copyright:    2003 D. Van Leer
* Description:  stringgrid class column and row utility functions
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
******************************************************************************/
#include "stdafx.h"
#include "cstringgrid.h"

#define MIN_HEIGHT 9
#define MAX_HEIGHT 101

// CellExists returns true if cell is in grid range
bool CStringGrid::CellExists(int col, int row)
{
  if(0 > col || col >= m_colCount || 0 > row || row >= m_rowCount)
    return false;
  else
    return true;
}

/************************************************
* set column width functions
************************************************/

// set individual column width in pixels
bool CStringGrid::SetColWidth(int col, int width)
{
  if(0 <= col && col < m_colCount)
  {
    TEXTMETRIC  tm;
    int         cxChar;

    GetTextMetrics(m_memdc, &tm);
    cxChar = tm.tmAveCharWidth;
    int maxColWidth = cxChar * MAX_COLUMN_CHARS;
    
    if(width < 0) width = 0;
    if(width > maxColWidth) width = maxColWidth;
    m_columns[col].m_width = width;
    return true;
  }
  else
    return false;
}

// set widths from array of number of characters
void CStringGrid::SetColCharWidths(int widths[])
{
  TEXTMETRIC  tm;
  int         cxChar;
  
  GetTextMetrics(m_memdc, &tm);
  cxChar = tm.tmAveCharWidth;
  
  for(int i = 0; i < m_colCount; i++)
    m_columns[i].m_width = widths[i] * cxChar;
}

//-----------------------------------------------------------------------------
// Function: InsertRow
// Use:      inserts row at specified point
// Args:     int row   - row number to insert at
//-----------------------------------------------------------------------------
int CStringGrid::InsertRow(int row)
{
  if(row < 0) row = 0;
  if(row > m_rowCount) row = m_rowCount;

    //vector<CellType>::iterator p;
  vector<RowType>::iterator p = m_rows.begin();

    /*for(int i = 0; i < m_colCount; i++)
    {
      //p = m_cells.begin() + m_colCount * row;
      //m_cells.insert(p, 1, CellType());
    }*/

  
  m_rows.insert(p+row,1,RowType());
  

  for(int i=0;i<m_colCount;i++)
	  m_rows[row].m_cells.push_back(CellType());

	m_rowCount++;	
	m_rows[row].visible = false;
	SetRowVisible(row,true);
    
	

    SetScrollbars();  
	return row;
}

//-----------------------------------------------------------------------------
// Function: InsertCol
// Use:      inserts column at specified point
// Args:     int col   - column number to insert at
//           int width - width of inserted column
//-----------------------------------------------------------------------------
void CStringGrid::InsertCol(int col, int width)
{
  if(col < 0) col = 0;
  if(col > m_colCount) col = m_colCount;
    
  int c = col;
  vector<CellType>::iterator p;
  
  for(int i = 0; i < m_rowCount; i++)
  {

    //p = m_cells.begin() + c;
    //m_cells.insert(p, 1, CellType());
    //c += (m_colCount + 1);
    p = m_rows[i].m_cells.begin()+c;
    m_rows[i].m_cells.insert(p,1,CellType());
  }
  m_colCount++;
  vector<ColumnType>::iterator r;
  r = m_columns.begin() + col;
  m_columns.insert(r, 1, ColumnType(width));
  SetScrollbars();
}

//-----------------------------------------------------------------------------
// Function: DeleteRow
// Use:      deletes specified row
// Args:     int row - row to delete
// Returns:  bool - true if row deleted, false if not
//-----------------------------------------------------------------------------
bool CStringGrid::DeleteRow(int row)
{

  if((row < 1) || (row >= m_rowCount))
  {
    return false;
  }
  else
  {
//    vector<CellType>::iterator p;
//    p = m_cells.begin() + m_colCount * row;

//    for(int i = 0; i < m_colCount; i++)
//    {
//      m_cells.erase(p);
//    }

	if(m_rows[row].visible) m_VisRows--;

	m_rows.erase(&m_rows[row]);
	  
	  
	m_rowCount--;
	
    SetScrollbars();
    return true;
  } 
}

//-----------------------------------------------------------------------------
// Function: DeleteCol
// Use:      deletes specified column
// Args:     int col - column to delete
// Returns:  bool - true if column deleted, false if not
//-----------------------------------------------------------------------------
bool  CStringGrid::DeleteCol(int col)
{
  if((col < 1) || (col >= m_colCount)) 
  {
    return false;
  }
  else
  {
    int c = col;
    vector<CellType>::iterator p;

    for(int i = 0; i < m_rowCount; i++)
    {

      p = m_rows[i].m_cells.begin() + c;
      m_cells.erase(p);
      //c += (m_colCount - 1);
    }
    m_colCount--;
    vector<ColumnType>::iterator r;
    r = m_columns.begin() + col;
    m_columns.erase(r);
    SetScrollbars();
    return true;
  }  
}

//-----------------------------------------------------------------------------
// Function: AutoSizeCol
// Use:      adjusts size of column to fit widest string
// Args:     int col - column to autosize
// Returns:  bool - true if width changed, false if not changed
//-----------------------------------------------------------------------------
bool CStringGrid::AutoSizeCol(int col)
{
  HGDIOBJ     hOldFont    = NULL;
  HFONT       hFixedFont  = CreateFontIndirect(&m_fxFont);
  HFONT       hCellFont   = CreateFontIndirect(&m_cellFont);
  bool        changed     = false;
  int         maxwidth    = 0;
  int         cellsize    = 0;
  SIZE        size;

  if(m_width == 0)
  {
      ::GetClientRect(m_gridhWnd, &m_clRect);
      m_top    = m_clRect.top;
      m_left   = m_clRect.left;
      m_height = m_clRect.bottom - m_clRect.top;
      m_width  = m_clRect.right - m_clRect.left;
	  m_ScreenRows = (m_height/m_rowHeight)-1;
  }

  if(col >= 0 && col < ColCount())
  {
    // select fixed font
    hOldFont   = SelectObject(m_memdc, hFixedFont);

    // get width of fixed row text
    if(CheckOptions(SGO_FIXEDROW))
    {
      GetTextExtentPoint32(m_memdc, Cell(col, 0),
                           strlen(Cell(col, 0)), &size);

      // allow for 5 pixel margins around text
      maxwidth = size.cx + 11;
    }
    
    //switch to cell font if not fixed column
    if(col > 0)
    {
      SelectObject(m_memdc, hCellFont); 
    }

    // get width of each row's text, keep widest value
    if(m_rowCount > 0)
    {
      for(int row = 1; row < m_rowCount; row++)
      {
        GetTextExtentPoint32(m_memdc, Cell(col, row),
                             strlen(Cell(col, row)), &size);
        cellsize = size.cx + 11;
        if(cellsize > maxwidth)
        {
          maxwidth = cellsize;
        }
      }
    }

    // limit to width of grid / 3
//    maxwidth = min(maxwidth, 20 + m_width / 3);
//    maxwidth = minmax(m_width / 3, maxwidth, 20);

    // update if different than current width
    if(maxwidth != m_columns[col].m_width)
    {
      changed = true;
      m_columns[col].m_width = maxwidth;
      SetScrollbars();
    }
  }
  SelectObject(m_memdc, hOldFont);
  DeleteObject(hFixedFont);
  DeleteObject(hCellFont);
  return changed;
}

//-----------------------------------------------------------------------------
// Function: VisibleRows
// Use:      returns number of visible rows
//-----------------------------------------------------------------------------
int CStringGrid::VisibleRows()
{
  //m_bottomRow = BottomRow();
  //return (m_bottomRow - m_topRow);
	return m_VisRows;
}

//-----------------------------------------------------------------------------
// Function: BottomRow
// Use:      returns bottom visible row
//           and sets m_clRect to client size
//-----------------------------------------------------------------------------
int CStringGrid::BottomRow()
{
	::GetClientRect(m_gridhWnd, &m_clRect);
  int br = m_topRow + ((m_clRect.bottom - HeadHeight()) / m_rowHeight) - 1;
  if(br > m_rowCount - 1) return m_rowCount - 1;
  else return br;
}

//-----------------------------------------------------------------------------
// Function: RightColumn
// Use:      returns right visible column
//           and sets m_clRect to client size
//-----------------------------------------------------------------------------
int CStringGrid::RightColumn()
{
	::GetClientRect(m_gridhWnd, &m_clRect);
  int x = m_columns[0].m_width;

  int i;
  for(i = m_leftCol; i < m_colCount; i++)
  {
    x += m_columns[i].m_width;
    if(x > m_clRect.right)
      break;
  }
  i--;
  return i;
}

//-----------------------------------------------------------------------------
// Function: SetColumn
// Use:      Sets selected column
// Args:     int col - column
//-----------------------------------------------------------------------------
void CStringGrid::SetColumn(int col)
{
  if(0 < col && col < m_colCount) m_col = col;
}

//-----------------------------------------------------------------------------
// Function: SetLeftColumn
// Use:      Sets left visible column
// Args:     col - column
//-----------------------------------------------------------------------------
void CStringGrid::SetLeftCol(int col)
{
  if(0 < col && col < m_colCount) m_leftCol = col;
}

//-----------------------------------------------------------------------------
// Function: SetRow
// Use:      Sets selected row
// Args:     int row - row
//-----------------------------------------------------------------------------
void CStringGrid::SetRow(int row)
{
  if(0 < row && row < m_rowCount) m_row = row;
}

//-----------------------------------------------------------------------------
// Function: SetTopRow
// Use:      Sets top visible row
// Args:     row - row
//-----------------------------------------------------------------------------
void CStringGrid::SetTopRow(int row)
{
  if(0 < row && row < m_rowCount) m_topRow = row;
}

void CStringGrid::SetRowHeight(int height)
{
  if(MIN_HEIGHT < height && height < MAX_HEIGHT)
  {
    m_rowHeight = height;
  }
}

void CStringGrid::SetTitleHeight(int height)
{
  if(MIN_HEIGHT < height && height < MAX_HEIGHT)
  {
    m_titleHeight = height;
  }
}

//-----------------------------------------------------------------------------
// Function: SetCloakCell
// Use:      Sets cloak cell text
// Args:     row,col,   text string
//-----------------------------------------------------------------------------
bool RowType::SetCloakCell(int col,int row,string &celltext)
{
	if(col >= 0 && col < cloakcols && row >= 0 && row < cloakrows)
	{
		m_CloakRows[row].m_cloakcells[col].m_string = celltext;
		return TRUE;
	}
	return FALSE;

}
//-----------------------------------------------------------------------------
// Function: SetCloakCellColor
// Use:      Sets cloak cell background color
// Args:     col,row,RGB
//-----------------------------------------------------------------------------
bool RowType::SetCloakCellColor(int col,int row,COLORREF color)
{
if(col >= 0 && col < cloakcols && row >= 0 && row < cloakrows)
{
	m_CloakRows[row].m_cloakcells[col].m_color = color;
	return TRUE;
}
return FALSE;
}
//-----------------------------------------------------------------------------
// Function:  SetCloakSize
// Use:     Set Soze of cloaked grid for all rows 
// Args:     number of cloaked rows,cols
//-----------------------------------------------------------------------------
bool RowType::SetCloakSize(int rows,int cols)
{
if(rows <= 0 && cols <= 0) return false;
else
{
	int i;
	cloakcols = cols;
	cloakrows = rows;
	m_CloakCols.resize(cols);
	m_CloakRows.resize(rows);
	for(i=0;i<rows;i++) m_CloakRows[i].m_cloakcells.resize(cols);
	MergeRows();
	MergeCols();
}
return true;
}

bool RowType::SetCloakCellSpan(int col,int row,int cspan = -1,int rspan = -1)
{

	int curcspan,currspan,i,ii,j,jj,t1;
	CloakCellType *cellptr;
	//CloakRowType *rowptr;


if(col >= 0 && col < cloakcols && row >= 0 && row < cloakrows)
{
	cellptr = &m_CloakRows[row].m_cloakcells[col];
//	rowptr = &m_CloakRows[row];
	curcspan = cellptr->colspan;
	currspan = cellptr->rowspan;

	if(cspan <= 0) cspan = curcspan;
	if(rspan <= 0) rspan = currspan;

	
		if(((col+cspan) <= cloakcols) && ((row+rspan) <= cloakrows))
		{

				if(curcspan > 1 || currspan > 1)
				{

					for(j=row,jj=row+currspan,ii=col+curcspan;j<jj;j++)		
					for(i=col;i<ii;i++)
					{
						m_CloakRows[j].m_cloakcells[i].in_span = false;
						m_CloakRows[j].m_cloakcells[i].corner = true;;
					}
					curcspan = 1;
					currspan = 1;


				}

					for(j=(row+currspan-1),jj=row+rspan,ii=col+cspan,t1=(col+curcspan-1);j<jj;j++)		
					for(i=t1;i<ii;i++)
					{
						m_CloakRows[j].m_cloakcells[i].in_span = true;

						if((i != col) || (j != row))
						m_CloakRows[j].m_cloakcells[i].corner = false;
					}
				/*} else if (cspan < curcspan || rspan < currspan)
				{

					for(j=(row+currspan-1),jj=row+rspan-1;j>jj;j--)		
					{
						for(i=col,ii=col+curcspan;i<ii;i++)
						{
							m_CloakRows[j].m_cloakcells[i].in_span = false;
							m_CloakRows[j].m_cloakcells[i].corner = true;
						}
					}

					for(j;j>=row;j--)
						for(i=(col+curcspan-1),ii=col+cspan-1;ii<i;i--)
						{
							m_CloakRows[j].m_cloakcells[i].in_span = false;
							m_CloakRows[j].m_cloakcells[i].corner = true;
						}
				}*/

				cellptr->colspan = cspan;
				cellptr->rowspan = rspan;

		} else return FALSE;

} else return FALSE;
/*

#ifdef _DEBUG
for(j=0;j<cloakrows;j++)
{
for(i=0;i<cloakcols;i++)
{
	DebugMsg("%c",m_CloakRows[j].m_cloakcells[i].corner ? 'x' : 'o');
}
DebugMsg("\n");
}

DebugMsg("---\n");
#endif
*/

return TRUE;
}


bool RowType::SetCloakColWidth(int col,int percent)
{

	if(col < cloakcols && percent <= 100 && percent >= 0)
	{
		m_CloakCols[col].width_per100 = percent;
		MergeCols();
		return TRUE;

	}
	return FALSE;

}

