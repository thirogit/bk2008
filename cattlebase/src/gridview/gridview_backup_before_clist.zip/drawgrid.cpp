/******************************************************************************
* File Name:    drawgrid.cpp
* Author:       D. Van Leer
* Date:         11/01/03
* Copyright:    2003 D. Van Leer
* Description:  stringgrid class DrawGrid function
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
******************************************************************************/
#include "stdafx.h"
#include "cstringgrid.h"

//-----------------------------------------------------------------------------
// Function: DrawGrid
// Use:      Draws String Grid
// Args:     none
// Returns:  none
//-----------------------------------------------------------------------------
void CStringGrid::DrawGrid()
{
 
  int i;

  //m_bottomRow = BottomRow();
  
  // if no fixed col set width to zero
  if(!CheckOptions(SGO_FIXEDCOL))
  {
    m_columns[0].m_width = 0;
  }
  else if(CheckOptions(SGO_NUMBERROWS))
  {
    NumberRows(m_numRowStart, m_numRowStep);
    AutoSizeCol(0);
  }

  m_rightCol  = RightColumn();

  // set up GDI objects
  int         iSaveDC = SaveDC(m_memdc);
  RECT        rc;
  RECT        selrc;

  HPEN        hpGrid      = CreatePen(PS_SOLID, 0, m_colors[SGC_GRIDLINE]);
  HPEN        hpGridDot   = CreatePen(PS_DOT,   0, m_colors[SGC_GRIDLINE]);
  HPEN        hpColRowSel = CreatePen(PS_SOLID, 0, m_colors[SGC_SELCELL]);
  HPEN        hpDots;
  HPEN        hpSelect;
  HPEN        hpXPHilite;





  HBRUSH      hbSelect    = CreateSolidBrush(m_colors[SGC_SELCELL]);
  HBRUSH      hbCellBkg   = CreateSolidBrush(m_colors[SGC_CELLBKGND]);
  HBRUSH      hbColumn_0  = CreateSolidBrush(m_colors[SGC_COLUMN_1]);
  HBRUSH      hbColumn_1  = CreateSolidBrush(m_colors[SGC_COLUMN_2]);
  HBRUSH      hbColumn_2  = CreateSolidBrush(m_colors[SGC_COLUMN_3]);
  HBRUSH      hbColumn_3  = CreateSolidBrush(m_colors[SGC_COLUMN_4]);
  HBRUSH      hbOddRows   = CreateSolidBrush(m_colors[SGC_ODDROWBARS]);

  HBRUSH	  hHighlight  = CreateSolidBrush(RGB(0xba,0xde,0xba)); //!!!



  HBRUSH      hbBkColor   = CreateSolidBrush(m_colors[SGC_GRIDBKGND]); //default rowbackground when RowType.m_color == -1
  



  HBRUSH      hbRowDot;
  HBRUSH      hbColDot;

  HFONT       hfFxFont    = CreateFontIndirect(&m_fxFont);
  HFONT       hfCellFont  = CreateFontIndirect(&m_cellFont);
  HFONT       hfTitleFont = CreateFontIndirect(&m_titleFont);


  HBRUSH oldBrush;

  //DebugMsg("screenRows=  %d\n",m_ScreenRows);

  if(!m_bGrayed)
  {
    hbRowDot    = CreateSolidBrush(m_colors[SGC_FXDROWTEXT]);
    hbColDot    = CreateSolidBrush(m_colors[SGC_FXDCOLTEXT]);
    hpDots      = CreatePen(PS_SOLID, 0, m_colors[SGC_SCROLLDOT]);
    hpXPHilite  = CreatePen(PS_SOLID, 0, RGB(230, 180, 0));
    if(!CheckOptions(SGO_XPSTYLE))
      hpSelect  = CreatePen(PS_SOLID, 0, m_colors[SGC_SELBORDER]);
    else
      hpSelect  = CreatePen(PS_SOLID, 0, RGB(100, 100, 220));
  }
  else
  {
    hbRowDot    = CreateSolidBrush(m_colors[SGC_GRAYTEXT]);
    hbColDot    = CreateSolidBrush(m_colors[SGC_GRAYTEXT]);
    hpDots      = CreatePen(PS_SOLID, 0, m_colors[SGC_GRAYTEXT]);
    hpSelect    = CreatePen(PS_SOLID, 0, m_colors[SGC_GRAYTEXT]);
    hpXPHilite  = CreatePen(PS_SOLID, 0, m_colors[SGC_GRAYTEXT]);
  }

  const UINT  dtStyle     = DT_SINGLELINE     |
                            DT_VCENTER        |
                            DT_END_ELLIPSIS   |
                            0;

  ::GetClientRect(m_gridhWnd, &m_clRect);

  int maxX  = GetSystemMetrics(SM_CXSCREEN);
  int maxY  = GetSystemMetrics(SM_CYSCREEN);

  SetBkMode(m_memdc, TRANSPARENT);
  SelectObject(m_memdc, hfCellFont); //default font
  SelectObject(m_memdc, hpGrid); //pen
  SelectObject(m_memdc, hbBkColor); //brush

  PatBlt(m_memdc, 0, 0, maxX, maxY, PATCOPY);
 // SelectObject(m_memdc, GetStockObject(HOLLOW_BRUSH));
  SelectObject(m_memdc, hfFxFont);

  // make sure selected cell always in visible section
  if(m_col < LeftColumn()) m_col = LeftColumn();
//  else if(m_col > RightColumn()) m_col = RightColumn();
  else if(m_col > m_rightCol) m_col = m_rightCol;

  if(m_row < TopRow()) m_row = TopRow();
  else if(m_row > m_bottomRow) m_row = m_bottomRow;

  // set rect for corner cell													
  rc.left   = 0;
  rc.top    = TitleHeight();
  rc.right  = m_columns[0].m_width;
  rc.bottom = HeadHeight();

HBRUSH br = CreateSolidBrush(m_colors[SGC_FXDCELL]);
oldBrush = (HBRUSH)SelectObject(m_memdc,br);

  // draw corner cell
  if(CheckOptions(SGO_FIXEDROW | SGO_FIXEDCOL) == true)
  {
    //BtnCell(rc);

	Rectangle(m_memdc,rc.left,rc.top,rc.right+1,rc.bottom+1);
    selrc = rc;
    selrc.right -= 5;    // allow margin of 5 pixels on right
    selrc.left  += 5;    // allow margin of 10 pixels on left
    SetTextColor(m_memdc,
                 m_colors[!m_bGrayed ? SGC_FXDCOLTEXT : SGC_GRAYTEXT]);
    DrawText(m_memdc, Cell(0, 0), -1, &selrc, dtStyle | DT_CENTER);
  }



  if(CheckOptions(SGO_SCROLLDOT | SGO_FIXEDROW | SGO_FIXEDCOL) == true)
  {
    // if not showing first col/row put indicator arrows in corner cell
    // don't draw arrows if column too narrow or short
    if(m_columns[0].m_width > 20 && m_rowHeight >= 10)
    {
      SelectObject(m_memdc, hpDots);
      if(m_topRow > 1)
      {
        SelectObject(m_memdc, hbRowDot);
        const POINT vertices[] =
        {
          {rc.left, rc.bottom},
          {rc.left + 10, rc.bottom},
          {rc.left + 5, rc.bottom - 5}
        };
        Polygon(m_memdc, vertices, 3);
      }
      if(m_leftCol > 1)
      {
        SelectObject(m_memdc, hbColDot);
        const POINT vertices[] =
        {
          {rc.right, rc.top},
          {rc.right, rc.top + 10},
          {rc.right - 5, rc.top + 5}
        };
        Polygon(m_memdc, vertices, 3);
      }
    }
  }

  // draw top row
  rc.left = m_columns[0].m_width;
  SetTextColor(m_memdc, m_colors[!m_bGrayed ? SGC_FXDCOLTEXT : SGC_GRAYTEXT]);



//  for(int i = m_leftCol; i < RightColumn() + 1; ++i)
  for(i = m_leftCol; i <= m_rightCol ; ++i)
  {
    rc.right = rc.left + m_columns[i].m_width;
    

	Rectangle(m_memdc,rc.left,rc.top,rc.right+ (i != m_rightCol) ,rc.bottom+1);
	//BtnCell(rc);

    selrc = rc;
    selrc.right -= 5;     // allow margin of 5 pixels
    selrc.left  += 5;     // on both sides of text
    DrawText(m_memdc, Cell(i, 0), -1, &selrc, dtStyle | DT_CENTER);
    rc.left += m_columns[i].m_width;
  }


SelectObject(m_memdc,oldBrush);
DeleteObject(br);

  // draw left column
  /*rc.left   = 0;
  rc.right  = m_columns[0].m_width;
  rc.top    = HeadHeight();
  SetTextColor(m_memdc, m_colors[!m_bGrayed ? SGC_FXDROWTEXT : SGC_GRAYTEXT]);
*/
  UINT align = DT_CENTER;
 /* if(GetColStyle(0) & SGA_ALIGNLEFT)
    align = DT_LEFT;
  else if(GetColStyle(0) & SGA_ALIGNRIGHT)
    align = DT_RIGHT;*/

 /* for(i = m_topRow; i < m_bottomRow + 1; ++i)
  {
    rc.bottom = rc.top + m_rowHeight;

    BtnCell(rc);
    selrc = rc;
    selrc.right -= 5;     // allow margin of 5 pixels
    selrc.left  += 5;     // on both sides of text
    DrawText(m_memdc, Cell(0, i), -1, &selrc, dtStyle | align);
    rc.top += m_rowHeight;

  }*/

int r;  


  // draw cell borders

int right = m_columns[0].m_width;
int iright = right;
int bottom = rc.top;
SelectObject(m_memdc, hpGrid);


   // draw horizontal lines

for(i = m_leftCol; i < m_rightCol + 1; ++i)
{
    right += m_columns[i].m_width;
}


MoveToEx(m_memdc, 0, 0, NULL);
LineTo  (m_memdc, right, 0);

int y = TitleHeight()+(m_rowHeight);
int yextra;
bool hlightON = false;
COLORREF tempcell = NO_COLOR,temprow = NO_COLOR,
         tempccloak = NO_COLOR,temprcloak = NO_COLOR,tempfxdcol = NO_COLOR;
HBRUSH hColTypeBrush;
HBRUSH hRowTypeBrush; // specified color for row
HBRUSH hCloakRow;
HBRUSH hCloakCell;
HBRUSH hFxdCol,hOld;
int cc,yy,off,cr,coloff,currcolw,ccols;;
CloakCellType *ccellptr;
int spani,ii,spanj,jj,cspan,rspan,currrowh;
CDC pDC;
POINT pt;
int ix,iy;

for(r = m_topRow; r < m_bottomRow + 1; ++r)
{

	if(!m_rows[r].visible) continue;

//	DebugMsg("ScreenRowsx = %d ,DrawGrid bottom = %d, top = %d, r = %d\n",m_ScreenRows,m_bottomRow,m_topRow,r);
	
	hlightON = (m_row_hlight == r);
	yy = y+m_rowHeight;
	yextra =  yy + !m_rows[r].hidden + m_rows[r].CloakHeight()+1;
 
	temprow = m_rows[r].m_color; 
	if(temprow != NO_COLOR)
			 hRowTypeBrush   = CreateSolidBrush(temprow);
		 	else hRowTypeBrush = hbBkColor;
		
	SelectObject(m_memdc, hRowTypeBrush);	
	Rectangle(m_memdc, 0, y,right, yextra);

	//FXDCOL
//DebugMsg("r = %d\n",r);
tempfxdcol = m_rows[r].m_cells[0].m_color; //!!!
if(tempfxdcol != NO_COLOR) hFxdCol = CreateSolidBrush(tempfxdcol);
else hFxdCol = hRowTypeBrush;
hOld = (HBRUSH)SelectObject(m_memdc,hFxdCol);

ix = m_columns[0].m_width+1;
iy = yy+1;
Rectangle(m_memdc,0,y,ix,iy);

if(m_rows[r].selected)
{
pDC.Attach(m_memdc);
pt.x = (ix + 0)/2 - 8; //assuming 16x16 picture
pt.y = (iy + y)/2 - 8;
m_imgList.Draw(&pDC,0,pt,ILD_NORMAL);
pDC.Detach();
}

SelectObject(m_memdc,hOld);







	if(hlightON) SelectObject(m_memdc, hHighlight);

	for(i = m_leftCol,iright = m_columns[0].m_width; i <= m_rightCol ; i++)
	{

		//select cell color 
		if(!hlightON)
		{
			tempcell = m_rows[r].m_cells[i].m_color;
			if(tempcell != NO_COLOR) hColTypeBrush   = (HBRUSH)CreateSolidBrush(tempcell);
			else hColTypeBrush  = hRowTypeBrush;  //if no color use row color
		
			SelectObject(m_memdc, hColTypeBrush);
		}
		
		SetRect(&selrc,iright,y,iright+m_columns[i].m_width + (i != m_rightCol) ,yy+1);
		Rectangle(m_memdc,selrc.left,selrc.top,selrc.right,selrc.bottom);
		//draw cell text

		DrawText(m_memdc, Cell(i, r), -1, &selrc, dtStyle | align);
   
		
		//SelectObject(m_memdc, hbBkColor);
		if(tempcell != NO_COLOR) DeleteObject(hColTypeBrush);

		iright += m_columns[i].m_width; 
    }
	
	//draw cloak rows
	off = yy;
	for(cr = 0;(cr < m_rows[r].cloakrows) && (!m_rows[r].hidden); cr++)
	{
	

		ccols = m_rows[r].cloakcols-1;

		//select brush
		temprcloak = m_rows[r].m_CloakRows[cr].m_color;
		//DebugMsg("r = %d, color = %08X\n",r,temprcloak);
		
			if(temprcloak != NO_COLOR)	hCloakRow = (HBRUSH)CreateSolidBrush(temprcloak);
			else hCloakRow = hRowTypeBrush;

			SelectObject(m_memdc,hCloakRow);

		
		for(cc = 0,coloff = 0;cc <= ccols ;cc++)
		{
			//select brush
			ccellptr = &m_rows[r].m_CloakRows[cr].m_cloakcells[cc];
			cspan = ccellptr->colspan;
			rspan = ccellptr->rowspan;

			if(ccellptr->in_span && !ccellptr->corner) continue;

			tempccloak = ccellptr->m_color;
			
			if(tempccloak != NO_COLOR)	hCloakCell = (HBRUSH)CreateSolidBrush(tempccloak);
			else hCloakCell = hCloakRow;

			SelectObject(m_memdc,hCloakCell);
			currcolw = (m_rows[r].m_CloakCols[cc].percent_width * right)/100;

			if(cspan > 1)
			{

				if((cc+cspan-1) == ccols)
				{
					currcolw = right-coloff-1;
				}
				else for(spani=cc+1,ii=cc+cspan;spani < ii;spani++)
					currcolw += ((m_rows[r].m_CloakCols[spani].percent_width * right)/100);
			
			}

			if(cc == ccols) 
				currcolw = right-coloff-1;
		
			selrc.left = coloff;
			selrc.top = off;
			selrc.right = coloff + currcolw +1;

			currrowh = m_rows[r].m_CloakRows[cr].pixel_height;
			if(rspan > 1)
			{

				for(spanj=cr+1,jj=cr+rspan;spanj<jj;spanj++)
					currrowh += m_rows[r].m_CloakRows[spanj].pixel_height;
			}

			selrc.bottom = off+currrowh+1;

			//selrc.bottom = off+m_rows[r].m_CloakRows[cr].pixel_height+1;
			


			Rectangle(m_memdc,selrc.left ,selrc.top,selrc.right ,selrc.bottom);

			DrawText(m_memdc,m_rows[r].m_CloakRows[cr].m_cloakcells[cc].m_string.c_str() , -1, &selrc, dtStyle | align);

			coloff += currcolw;
			

		}
		off += m_rows[r].m_CloakRows[cr].pixel_height;

		if(temprcloak != NO_COLOR) DeleteObject(hCloakRow);
		if(tempccloak != NO_COLOR) DeleteObject(hCloakCell);

	}

y += (m_rowHeight) + m_rows[r].CloakHeight() ;

if(temprow != NO_COLOR) DeleteObject(hRowTypeBrush);
if(tempcell != NO_COLOR) DeleteObject(hColTypeBrush);


}









/* 

  for(int y = TitleHeight(); y < bottom + m_rowHeight; y += (m_rowHeight))
  {
    MoveToEx(m_memdc, 0, y, NULL);
    LineTo  (m_memdc, right, y);
    if(CheckOptions(SGO_EXTENDLINES) && right < m_clRect.right &&
//        RightColumn() < m_colCount - 1 && y > 1)
        m_rightCol < m_colCount - 1 && y > 1)
    {
      SelectObject(m_memdc, hpGridDot);
      LineTo(m_memdc, right + ((m_clRect.right - right) / 2), y);
      SelectObject(m_memdc, hpGrid);
    }
  }
 */




  /*// draw verticle lines
 right = m_columns[0].m_width;
 

  MoveToEx(m_memdc, 0, 0, NULL);
  LineTo  (m_memdc, 0, bottom);
  MoveToEx(m_memdc, 0 + m_columns[0].m_width, 0, NULL); //for first column
  LineTo  (m_memdc, 0 + m_columns[0].m_width, bottom);


  if(CheckOptions(SGO_EXTENDCELLS) && bottom < m_clRect.bottom)
  {
    LineTo(m_memdc, right, m_clRect.bottom );
  }
  else if(CheckOptions(SGO_EXTENDLINES) && bottom < m_clRect.bottom &&
            m_bottomRow < m_rowCount - 1)
  {
    SelectObject(m_memdc, hpGridDot);
    LineTo(m_memdc, right, bottom + ((m_clRect.bottom - bottom) * 2 / 3));
    SelectObject(m_memdc, hpGrid);
  }




//  for(int i = m_leftCol; i < RightColumn() + 1; ++i)
  for(i = m_leftCol; i < m_rightCol + 1; ++i)
  {
    right += m_columns[i].m_width;
    MoveToEx(m_memdc, right, 0, NULL);
    LineTo  (m_memdc, right, bottom);
    if(CheckOptions(SGO_EXTENDLINES) && bottom < m_clRect.bottom &&
        m_bottomRow < m_rowCount - 1)
    {
      SelectObject(m_memdc, hpGridDot);
      LineTo(m_memdc, right, bottom + ((m_clRect.bottom - bottom) * 2 / 3));
      SelectObject(m_memdc, hpGrid);
    }
  }


*/






  if(CheckOptions(SGO_TITLE))
  {
    // set rect for title cell
    rc.left   = 0;
    rc.top    = 0;
    rc.right  = right;
    rc.bottom = m_titleHeight;

    // draw title cell
    BtnCell(rc);
    selrc = rc;
    selrc.right -= 5;     // allow margin of 5 pixels on right
    selrc.left  += 10;    // allow margin of 10 pixels on left
    SelectObject(m_memdc, hfTitleFont);
    SetTextColor(m_memdc,
                 m_colors[!m_bGrayed ? SGC_TITLETEXT : SGC_GRAYTEXT]);
    DrawText(m_memdc, m_titleString.c_str(), -1, &selrc, dtStyle | DT_CENTER);
  }

/*  // draw grid text
  SelectObject(m_memdc, hfCellFont);
  rc.left = m_columns[0].m_width;

//  for(int c = m_leftCol; c < RightColumn() + 1; ++c)
  for(int c = m_leftCol;  c < m_rightCol + 1; ++c)
  {
    // set text alignment for column
    UINT align = DT_CENTER;

    if(GetColStyle(c) & SGA_ALIGNLEFT)
      align = DT_LEFT;
    else if(GetColStyle(c) & SGA_ALIGNRIGHT)
      align = DT_RIGHT;

    rc.top    = HeadHeight();
    rc.right  = rc.left + m_columns[c].m_width;




    for(int r = m_topRow; 0 && r < m_bottomRow + 1; ++r)
    {
      rc.bottom = rc.top + m_rowHeight;
      selrc = rc;
      selrc.top++;
      selrc.left++;

	  
      if((CheckOptions(SGO_ROWSEL)  && m_row == r) ||
         (CheckOptions(SGO_CELLSEL) && m_row == r && m_col == c) ||
         (CheckOptions(SGO_COLSEL)  && m_col == c))
      {
        SelectObject(m_memdc, hbSelect);
        if(CheckOptions(SGO_CELLSEL) && m_row == r && m_col == c)
          SelectObject(m_memdc, hpSelect);
        else
          SelectObject(m_memdc, hpColRowSel);

        SetTextColor(m_memdc,
          m_colors[!m_bGrayed ? SGC_SELTEXT : SGC_GRAYTEXT]);

	
	

        if(CheckOptions(SGO_XPSTYLE | SGO_CELLSEL)
                        && m_row == r && m_col == c)
        {
          BtnCell(rc);
          SelectObject(m_memdc, GetStockObject(HOLLOW_BRUSH));
          RoundRect(m_memdc, selrc.left, selrc.top,
                    selrc.right, selrc.bottom, 5, 5);
          SelectObject(m_memdc, hpXPHilite);
          MoveToEx(m_memdc, rc.left + 4, rc.bottom - 2, NULL);
          LineTo(m_memdc, rc.right - 2, rc.bottom - 2);
          MoveToEx(m_memdc, rc.right - 2, rc.top + 4, NULL);
          LineTo(m_memdc, rc.right - 2, rc.bottom - 2);
        }
        else
        {

		  
  	
 	
          ///Rectangle(m_memdc, selrc.left, selrc.top,
             //       selrc.right, selrc.bottom);
        }
      }
      else
      {
        int cc = GetColColor(c);

        SetTextColor(m_memdc,
          !m_bGrayed ? GetCellColor(c, r) : m_colors[SGC_GRAYTEXT]);

        // fill cell background
        if(CheckOptions(SGO_ROWBARS))
        {
          if((r % 2) == 1)
            FillRect(m_memdc, &selrc, hbOddRows);
          else
            FillRect(m_memdc, &selrc, hbCellBkg);
        }
        else
        {
          if(cc == SGC_CELLBKGND)
            FillRect(m_memdc, &selrc, hbCellBkg);
          else if(cc == SGC_COLUMN_1)
            FillRect(m_memdc, &selrc, hbColumn_0);
          else if(cc == SGC_COLUMN_2)
            FillRect(m_memdc, &selrc, hbColumn_1);
          else if(cc == SGC_COLUMN_3)
            FillRect(m_memdc, &selrc, hbColumn_2);
          else if(cc == SGC_COLUMN_4)
            FillRect(m_memdc, &selrc, hbColumn_3);
        }
      }
      selrc = rc;
      selrc.right -= 5;     // allow margin of 5 pixels
      selrc.left  += 5;     // on both sides of text
      SelectObject(m_memdc, GetStockObject(HOLLOW_BRUSH));
      
//      DrawText(m_memdc, m_cells[m_colCount * r + c].m_string.c_str(), -1, &selrc, dtStyle | align);
      DrawText(m_memdc, Cell(c, r), -1, &selrc, dtStyle | align);
      rc.top += m_rowHeight;
    }
    rc.left = rc.right;
  }*/

  	
  m_si.fMask  = SIF_POS;
  m_si.nPos   = m_leftCol;
  ::SetScrollInfo(m_gridhWnd, SB_HORZ, &m_si, TRUE);

  m_si.fMask  = SIF_POS;
  m_si.nPos   = m_topRow;
  ::SetScrollInfo(m_gridhWnd, SB_VERT, &m_si, TRUE);

  ::InvalidateRect(m_gridhWnd, NULL, TRUE);

  // clean up
  RestoreDC(m_memdc, iSaveDC);
  DeleteObject(hbBkColor);
  DeleteObject(hbRowDot);
  DeleteObject(hbColDot);
  DeleteObject(hbSelect);
  DeleteObject(hbCellBkg);
  DeleteObject(hbColumn_0);
  DeleteObject(hbColumn_1);
  DeleteObject(hbColumn_2);
  DeleteObject(hbColumn_3);
  DeleteObject(hbOddRows);
  DeleteObject(hfFxFont);
  DeleteObject(hfCellFont);
  DeleteObject(hfTitleFont);
  DeleteObject(hpGrid);
  DeleteObject(hpGridDot);
  DeleteObject(hpDots);
  DeleteObject(hpSelect);
  DeleteObject(hpColRowSel);
  DeleteObject(hpXPHilite);
  DeleteObject(hHighlight);
}
